import json, base64
S='/tmp/claude-0/-home-claude/90f9075a-8e8a-5948-8a8e-80f1167be059/scratchpad/'
b64=lambda p:'data:image/jpeg;base64,'+base64.b64encode(open(S+p,'rb').read()).decode()
imgs={'olga_struct':'olga/img_struct.jpg','olga_arch':'olga/img_arch.jpg','olga_beam':'olga/img_beam.jpg',
 'hofim_pB':'hofim/ov_B110.jpg','hofim_pC':'hofim/ov_C110.jpg','hofim_walls':'hofim/fig_walls_220.jpg','hofim_slab':'hofim/fig_slab_220.jpg','hofim_ocr':'hofim/fig_ocr230.jpg','olga_ceil':'olga/fig_ceil.jpg','olga_faces':'olga/fig_faces.jpg'}
I={k:b64(v) for k,v in imgs.items()}
t=open('/home/claude/system/app_tpl.html',encoding='utf-8').read()
data=open('/home/claude/system/data.json',encoding='utf-8').read().replace('</','<\\/')
sample=open('/home/claude/system/sample_layers.json',encoding='utf-8').read().replace('</','<\\/')
out=t.replace('{{DATA}}',data).replace('{{SAMPLE}}',sample).replace('{{IMGS}}',json.dumps(I))
open('/home/claude/system/kamuyot_system.html','w',encoding='utf-8').write(out)
print(len(out)//1024,'KB')
