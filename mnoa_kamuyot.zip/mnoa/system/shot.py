from playwright.sync_api import sync_playwright
import sys
O='/home/claude/system/'
pages=sys.argv[1:] or ['dash']
with sync_playwright() as p:
    b=p.chromium.launch()
    for vw,tag in ((1280,'d'),(390,'m')):
        pg=b.new_page(viewport={'width':vw,'height':900})
        errs=[]; pg.on('pageerror',lambda e:errs.append(str(e))); pg.on('console',lambda m: errs.append(m.text) if m.type=='error' else None)
        for h in pages:
            pg.goto('file://'+O+'kamuyot_system.html#'+h); pg.wait_for_timeout(900)
            sw=pg.evaluate('[document.documentElement.scrollWidth,innerWidth]')
            pg.screenshot(path=f'{O}s_{tag}_{h}.png',full_page=True)
            print(tag,h,sw,errs[-3:])
    b.close()
