# Verification report: data.json (olga, hofim)

Independent recompute from the source JSON, pickle, xlsx and PDF files. No source files were modified.

## Summary
Almost every number checks out. There are 2 hard errors (sheet counts) and 3 smaller ones:

| # | Field | data.json | Correct | Severity |
|---|---|---|---|---|
| A | hofim.sheets.struct | 73 | **67** (B 38 + C 29) | FAIL |
| B | hofim.sheets.arch | 37 | **34** (B 17 + C 14 + common 3). The 37 includes 3 copies of the list-of-drawings PDF. | FAIL |
| C | hofim.piles[C, Ø60].read | 52 | **106** (pilesC110.json, piles without the `est` flag). piles_summary.json (14:00) predates pilesC110.json (14:08), so the summary is stale. build_hofim.py already gives 106. Total read = 279. | FAIL (minor) |
| D | hofim.rebar[slabs].cov "493 מתוך 740" | 493 | **524** labels / 740 marks (slab_rebar.json) | FAIL (minor) |
| E | slab_rebar.json sheets 530 and 540 | — | They are byte-identical entries (kg 3479.36, est 4639.14, labels 9, marks 12), but the PDFs differ (different md5). This looks like a copy or duplicate in the engine. Without 540: read 71.4 t, est 99.2 t. | WARN |

## 1. Olga BOQ (gan structure "01 מבנה הגן" only)
| Row | a (2020) codes | a | b (2021) codes | b | Result |
|---|---|---|---|---|---|
| Foundations m³ | 02.1.060 | 22 | 02.012.0030 + .0200 + .0210 (6+3+14) | 23 | PASS |
| 20cm floor m² | 02.3.010 | 157 | 02.050.0050 | 150 | PASS |
| 25cm safe-room floor | 02.3.011 | 25 | 02.050.0060 | 27 | PASS |
| Concrete walls m³ | 02.4.010 | 70 | 02.061.0030/40/60/72 (27+9+32+14=82) + 02.042.0011 basement walls 4 | 86 | PASS |
| Beams m³ | 02.5.010 | 37 | 02.072.0041 | 35 | PASS |
| Columns m³ | 02.4.020 | 6 | 02.062.0091 + .0230 (7+1) | 8 | PASS |
| 25cm slabs m² | 02.6.010 | 275 | 02.081.0050 | 305 | PASS |
| 40cm safe-room roof | 02.6.011 | 25 | 02.081.0070 | 27 | PASS |
| 20cm shaft roof | 02.6.012 | 5 | 02.081.0040 | 5 | PASS |
| Rebar t | 02.8.010 | 28 | 02.100.0011 | 30 | PASS |
| Blocks total | 110+40+130 | 280 | 118+80+155 | 353 | PASS |
| 10cm partitions | 04.1.010 | 110 | 04.010.0020 | 118 | PASS |
| 20cm blocks + 22cm pumice | 04.1.020 + 04.1.030 (40+130) | 170 | 04.010.0040 + 04.030.0040 (80+155) | 235 | PASS |
| Flooring | 10.1.015 | 245 | 10.031.0495 | 268 | PASS |

BOQ totals: y2020 2,128,069 PASS. y2021 1,777,712.6 (rounds to 1,777,713) PASS. conc2020 488,280 PASS. conc2021 578,683 PASS. These match the gan-only chapter 02 (all structures: 527,501 and 582,203).

Engine "e" values all match ch02.json:
- foundations 27.94
- 31.6/0.2 = 158
- 6.2/0.25 = 24.8
- walls 70.3
- 80.75/0.25 = 323
- 9.92/0.4 = 24.8
- 0.94/0.2 = 4.7

Nit: the foundations finding gives "בלעדיו 21.6". 27.94 − 6.4 = **21.5**.

## 2. Olga beams (beams_demo.json)
- The file has 21 beams and is identical to data.json.beams.
- Concrete is **22.68 m³** and rebar is **2,814 kg (2.81 t)**: PASS.
- ch02.json lists 2,810 kg for beams, a trivial difference.
- The rebar parts sum to 18.29 t, which matches the "18.3 טון" in the finding (ch02 R = 18,281.6 kg): PASS.
- Finding amount 18,500: 12.3–14.3 m³ × 1,400 = 17.2k–20.0k: PASS.
- Slabs "+6% to +17%": 323/305 = +5.9%, 323/275 = +17.5%: PASS.

## 3. Hofim BOQ, building B (01.*) and C (03.*)
All values PASS. Spot-checked 20 items against the original xlsx, all identical.
- **Piles:** 01.23.010.0020/0040/0060 = 310 @212, 1900 @280, 400 @360. 03.23.010.0040/0060 = 1940 @280, 65 @360. The "עד 10 מ'" wording applies to Ø50 and Ø60 only (Ø70 says "עד 15 מ'"). 310 + 1900 + 1940 = 4,150 m: PASS.
- **Walls (01.02.061):** 20:235, 25:80, 30:25, 35:145, 40:395, 95:20 (.0087). Columns: 01.02.999.0001 = 65, .0002 = 42. Foundation walls: 01.02.042.0010 = 25, .0030 = 40.
- **Slabs:**
  - Precast: 01.03.030.0078 = 505, .0118 = 500 (1005).
  - 01.02.999.0251 36cm = 185. 01.02.081.0085 75cm = 20.
  - On-grade: 050.0060 = 830, .0070 = 75, 999.0050 = 855, total 1760.
  - Suspended 20–22cm: 999.0040 = 1570.
  - Sloped (082.0030/31/33/60): 115/220/35/900.
  - Arched: 999.0021 = 425. 30cm: 081.0060 = 900.
- **Rebar:** 01.02.100.0011 = 430 t, .0031 mesh = 10 t.
- **Waterproofing:** 01.05.013.0040 = 1400. Paved roof: 01.10.099.0003 = 230. 1400 + 230 = 1630: PASS.
- **Flooring:** 01.10.099.0001 = 2800.
- **Totals:**
  - total 51,686,769: PASS
  - stage B 25,085,858.5: PASS
  - stage C 20,201,569.5: PASS
  - concrete B (01.02) 7,402,411: PASS

## 4. Hofim piles
- piles010 has 80 piles (Ø50 8, Ø60 48, Ø70 24) and piles110 has 116 (Ø50 15, Ø60 95, Ø70 6). Building B therefore has Ø50 23, Ø60 143, Ø70 30: PASS.
- pilesC110 has 152 piles (Ø60 147, Ø70 5): PASS.
- **Total 348**: PASS.
- All piles have L = 12.0, and there are no duplicate coordinates.
- Read (not est) counts:
  - B: 18 / 129 / 24: PASS
  - C Ø70: 2: PASS
  - **C Ø60: 106, not 52** (see C above)
- Gap valuation: (310−276)·212 + (1900−1716)·280 + (400−360)·360 + (1940−1764)·280 + (65−60)·360 = 7,208 + 51,520 + 14,400 + 49,280 + 1,800 = **124,208 ₪**: PASS.
- Meters per pile: 13.48 / 13.29 / 13.33 / 13.20 / 13.00, overall 13.26: PASS.
- Wording: "constant ratio, +1.2 m per pile" is approximate. The actual extra per pile ranges from 1.0 to 1.48 m.

## 5. Hofim rebar
- **Beams:** br_a (5 sheets) 9,028.4 kg plus br_b (8 sheets) 20,937.3 kg = **29,965.6 kg**: PASS. 13 sheets, of which 070 is empty, which matches "12 גיליונות". beam_rebar.pkl is the same as br_b.
- **Slabs:** sum of kg = **74,849 kg (74.8 t)** and sum of est = **103,798 kg (103.8 t)**: PASS. Labels are 524 of 740, not 493 (see D). Sheets 530 and 540 may be duplicates (see E).
- **Walls:** kg_cnt = **28,991 kg (29.0 t)** and vert = **15,885 kg (15.9 t)**: PASS. Labels 885 of 1,073: PASS.
- Grand total 30 + 75 + 29 ≈ 134 t read. The "tot" values 47 + 104 + 53 = 204 support "כ-200 טון": PASS.
- The "כ-2,800 תוויות" figure could not be reproduced. Slab labels 524 + wall labels 885 + beam main lines 971 = 2,380, or about 2,960 with stirrup sets. Treat it as approximate.
- "≈1.4M": (430 − 204) × 6,200 = 1.40M: PASS.
- "הכתב מניח כ-154 ק"ג/מ"ק": my estimate of the BOQ-B cast concrete is about 3,075 m³, which gives **about 140 kg/m³**. That is about 129 if precast slabs are included, and 117 if you use the B-40 surcharge quantity (3,670 m³). 154 is not reproduced, so I suggest "כ-130–140".

## 6. Hofim walls (walls_vol.json, vol + bs)
- By thickness: wall_20 141.2, 25 82.3, 30 6.9, 35 66.2, 40 179.9, 45 167.0. 40+45 = 346.9.
- **Walls total 643.4 m³**: PASS.
- **Columns:** col_rect 49.1 + col_round 27.6 = **76.7 m³**: PASS.
- **Sum 720.1**: PASS.
- Every row in data.json walls.e (82/347/141/66/7/77, and 49/28) matches.

## 7. Internal arithmetic
- hofim gap_total 2,624,208 = 1,400,000 + 690,000 + 410,000 + 124,208: PASS.
- olga gap_total 18,500 = the single amount: PASS.
- Walls: engine 82+347+141+66+7+77 = 720, BOQ 80+395+235+145+45+107 = 1,007. 720/1,007 = 71.5%, so the BOQ is 28.5% higher than the engine: PASS. Valuing the gap per thickness gives about 411k ₪, which matches "≈410,000": PASS.
- Slabs: BOQ (excluding on-grade) 1005+185+20+2585+900+425+255 = **5,375**: PASS. 2585 = 1570 + 115 + 900.
  - The engine figure of **3,527** is the sum of sheets 220, 320, 420 and 520 (3,526.6): PASS.
  - The rows shown add up to only 3,518. The 8 m² of cast_15 on sheet 520 is not shown in any row.
  - 3,527 / 5,375 is 34% lower.
  - Valuing the gap per row gives about 700k, so "≈690k" is plausible.
- Engine slab rows in slab_areas.json:
  - precast 878.8 = pre_20 + pre_30 + **pre_36 78.7 + pre_75 6.4**. The note "20 ו-30 ס"מ" is incomplete; 20 and 30 alone come to 793.7.
  - 36cm 202.0, 75cm 15.4, 30cm 559.6, 40cm 184.3
  - 20cm 1,678.3 (claimed 1,679)
  - on-grade 1,488.8 is sheet 120 only
- Note: sheets 020 and 070 (522.1 m² each, an identical total; 1,044 m² together) are excluded from both the on-grade and suspended totals. Check whether 020 or 070 is a real slab.

## 8. Drawing sheet counts (Hofim). All PDFs are single-page and the archives match the extracted files.
- **Structural:** קונסטרוקציה B = 38 PDFs (CONST_B_010…540) plus קונסטרוקציה C = 29 (CONST_C_110…540), giving **67**, not 73.
- **Architecture:** 37 PDFs in total, but 3 of them are the same list-of-drawings file (md5 5454d7ba). That leaves **34 sheets**: B 17, C 14, common sections/elevations 3 (403_50-PR, 403_B09, 403_C06).
  - 403_20A, 30N and 40M appear in both B and C, but the files are different (different md5), so they are counted twice.
  - Counting each sheet number once would give 31.
