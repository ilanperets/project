# מנוע כמויות: קבצי עבודה (26.10.2026)

המסמך המלא: MENOA_KAMUYOT.md


- system/kamuyot_system.html — המערכת (לוח בקרה, פרויקטים, ממצאים). נפתח בכל דפדפן.
- system/data.json — כל התוצאות במבנה אחד. system/build.py בונה את המערכת מ-app_tpl.html ו-data.json.
- system/verify_report.md — דוח הבדיקה העצמאית של כל המספרים.
- scripts/ — קוד המנוע (Python: PyMuPDF, numpy, scipy, Pillow, pytesseract).
  - hofim_walls.py / hofim_vol.py — קירות ועמודים לפי שכבות
  - hofim_fp.py / hofim_marks.py / hofim_slabarea2.py — תקרות ועוביים
  - piles.py — כלונסאות; glyphs.py, beam_rebar.py, fontb.py — קריאת טקסט מצויר (ברזל)
  - olga_*.py, walls_layers.py, beams_calc.py — גני אולגה
- results/ — תוצאות ביניים ותמונות. boq/ — כתבי הכמויות שנקראו.
- קבצי התוכניות המקוריים (כ-420MB) לא נכללו. הם זמינים באתרי המכרזים של החברה הכלכלית חדרה.
