import pymupdf as fitz, sys, math, numpy as np, json
from PIL import Image
from scipy import ndimage as ndi
CM=2.0
def replay(src, pred, width=None, fill=True):
    nd=fitz.open(); pg=nd.new_page(width=src.mediabox.width,height=src.mediabox.height)
    sh=pg.new_shape()
    for d in src.get_drawings():
        its=pred(d)
        if not its: continue
        for it in its:
            k=it[0]
            if k=='l': sh.draw_line(it[1],it[2])
            elif k=='c': sh.draw_bezier(it[1],it[2],it[3],it[4])
            elif k=='re': sh.draw_rect(it[1])
            elif k=='qu': sh.draw_quad(it[1])
        if fill: sh.finish(color=None,fill=(0,0,0),even_odd=d.get('even_odd',False),closePath=True)
        else: sh.finish(color=(0,0,0),width=width or 1,closePath=False)
    sh.commit(); return nd,pg
def raster(pg, scale, rot):
    z=scale*0.03528/CM  # px per pt
    pix=pg.get_pixmap(matrix=fitz.Matrix(z,z).prerotate(0),colorspace=fitz.csGRAY,alpha=False)
    a=np.frombuffer(pix.samples,np.uint8).reshape(pix.height,pix.width)<128
    return a
def masks(pdf, scale):
    src=fitz.open(pdf)[0]
    def solid(d): return d['items'] if d['layer']=='s-solid' and 'f' in d['type'] else None
    def hatch(d):
        if d['layer']!='S_HATCH' or d['type']!='s' or round(d.get('width') or 0,2)!=0.36: return None
        out=[]
        for it in d['items']:
            if it[0]!='l': continue
            v=it[2]-it[1]; L=abs(v)
            if L<2: continue
            a=math.degrees(math.atan2(v.y,v.x))%180
            if min(abs(a-45),abs(a-135))<8: out.append(it)
        return out or None
    _,p1=replay(src,solid); S=raster(p1,scale,0)
    _,p2=replay(src,hatch,width=0.8,fill=False); Hl=raster(p2,scale,0)
    return S,Hl,src
def hatch_regions(Hl):
    h=ndi.binary_closing(Hl,structure=np.ones((7,7)))
    h=ndi.binary_fill_holes(h) & ndi.binary_dilation(Hl,iterations=4)
    return h
def thickness_split(m):
    """returns list of (area_m2, thickness_cm, kind) per component"""
    lab,n=ndi.label(m); out=[]
    dt=ndi.distance_transform_edt(m)
    for i,sl in enumerate(ndi.find_objects(lab),1):
        mm=lab[sl]==i; area=mm.sum()*CM*CM/1e4
        if area<0.01: continue
        d=dt[sl]*mm
        # ridge: local maxima of dt
        mx=ndi.maximum_filter(d,size=3); ridge=(d>=mx)&(d>0)
        t=np.median(d[ridge])*2*CM
        h,w=mm.shape; ext=max(h,w)*CM
        comp=area/((max(h,w)*CM/100)*(min(h,w)*CM/100)+1e-9)
        out.append(dict(area=round(area,4),t=round(t,1),ext=round(ext),sl=[sl[0].start,sl[0].stop,sl[1].start,sl[1].stop],i=i))
    return out,lab
if __name__=="__main__":
    pdf,scale,tag=sys.argv[1],float(sys.argv[2]),sys.argv[3]
    S,Hl,src=masks(pdf,scale)
    H=hatch_regions(Hl)
    # remove title column / legend: x < 290pt
    z=scale*0.03528/CM; cut=int(290*z); S[:, :cut]=False; H[:, :cut]=False
    H&=~S
    rs,labS=thickness_split(S); rh,labH=thickness_split(H)
    rh=[r for r in rh if r['t']>=9]
    json.dump(dict(solid=rs,hatch=rh),open(f"{tag}.json","w"))
    rgb=np.full(S.shape+(3,),255,np.uint8); rgb[S]=(220,60,50)
    keep=np.isin(labH,[r['i'] for r in rh]); rgb[keep]=(40,150,70); rgb[H&~keep]=(200,200,200)
    Image.fromarray(rgb).save(f"{tag}.png")
    print("solid",round(sum(r['area'] for r in rs),2),"hatch",round(sum(r['area'] for r in rh),2))
