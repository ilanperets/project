import json, pickle, collections, base64
S='/tmp/claude-0/-home-claude/90f9075a-8e8a-5948-8a8e-80f1167be059/scratchpad'
H=S+'/hofim/'
W=lambda d:0.00617*d*d
# ---------- OLGA ----------
o20=json.load(open(f'{S}/olga2020.json')); o21=json.load(open(f'{S}/olga2021.json'))
beams=json.load(open(f'{S}/olga/beams_demo.json'))
olga=dict(id='olga',name='גני ילדים אולגה',place='חדרה',client='החברה הכלכלית לפיתוח חדרה',
 docs='מכרז T0620 · אומדן T0621',scale='1:50',
 sheets=dict(struct=14,arch=6),layers=dict(arch='42–51',struct='אין'),
 boq=dict(y2020=round(sum(i['total'] or 0 for i in o20)),y2021=round(sum(i['total'] or 0 for i in o21)),
          conc2020=488280,conc2021=578683),
 concrete=[
  dict(n='יסודות',u='מ"ק',e=27.9,a=22,b=23,note='כולל יסוד משותף אלכסוני של 6.4 מ"ק בין עמודים 2–3, שלא ברור אם הוא חדש'),
  dict(n='רצפה 20 ס"מ',u='מ"ר',e=158,a=157,b=150,note=''),
  dict(n='רצפת ממ"ד 25 ס"מ',u='מ"ר',e=24.8,a=25,b=27,note='צורת L: ממ"ד וחדר צמוד'),
  dict(n='קירות בטון',u='מ"ק',e=70.3,a=70,b=86,note='באומדן 2021: 82 מ"ק קירות ועוד 4 קירות מסד'),
  dict(n='קורות',u='מ"ק',e=22.7,a=37,b=35,note='21 קורות שנקראו מגיליונות הקורות, בעומק מלא'),
  dict(n='עמודים',u='מ"ק',e=None,a=6,b=8,note='רוב העמודים מוטמעים בקירות ועוד לא הופרדו'),
  dict(n='תקרות 25 ס"מ',u='מ"ר',e=323,a=275,b=305,note='כ-5 מ"ר מזה קורות בולטות שנספרו כתקרה'),
  dict(n='תקרת ממ"ד 40 ס"מ',u='מ"ר',e=24.8,a=25,b=27,note=''),
  dict(n='תקרת פיר מעלית 20 ס"מ',u='מ"ר',e=4.7,a=5,b=5,note=''),
 ],
 rebar=dict(parts=[('קורות','read',2.81),('רצפה ‎−0.15','read',3.37),('תקרה ‎+3.65','read',3.22),('ממ"ד','derived',4.27),('עמודים וקצוות קירות','derived',1.00),('גג ‎+7.25','est',3.62)],a=28,b=30,
   missing='יסודות, מדרגות, ורשת עליונה שמסומנת "לפי הנדרש"'),
 beams=beams,
 items=[
  dict(g='אלומיניום',c='א1',n='ויטרינה 420/600',e='1',a='1',s='ok',note='מופיעה בשתי הקומות. פריט בגובה כפול נספר פעם אחת'),
  dict(g='אלומיניום',c='א2',n='ויטרינה 430/280',e='1',a='1',s='ok'),
  dict(g='אלומיניום',c='א3',n='ויטרינה 420/280',e='1',a='1',s='ok'),
  dict(g='אלומיניום',c='א4',n='ויטרינה 420/280',e='1',a='1',s='ok'),
  dict(g='אלומיניום',c='א5',n='חלון קבוע 120/200',e='2',a='2',s='ok'),
  dict(g='אלומיניום',c='א6',n='רצף חלונות 100/400',e='1',a='1',s='ok',note='חלון בגובה כפול בחדר המדרגות'),
  dict(g='אלומיניום',c='א7',n='דלת עם חלון עליון',e='1',a='1',s='ok'),
  dict(g='אלומיניום',c='א8',n='ויטרינה 225/240',e='2',a='2',s='ok'),
  dict(g='אלומיניום',c='א10–א12',n='חלונות קיפ והזזה',e='3 + 3 לאישור',a='6',s='near',note='בקומה א׳ התגיות מסובבות וחלקן קטועות'),
  dict(g='אלומיניום',c='א13',n='חלונות עגולים',e='—',a='4',s='na',note='מסומנים "ראה חזית". נספרים מגיליון החזיתות'),
  dict(g='אלומיניום',c='א14',n='רפפת עשן',e='0',a='1',s='gap',note='לא מופיעה בתוכניות הקומות'),
  dict(g='נגרות',c='נ1–נ3',n='מחיצות טרספה, דלת נכים, מטבחון',e='2 + 2 + 2',a='2 + 2 + 2',s='ok'),
  dict(g='נגרות',c='נ5',n='לוח תצוגה 120/120',e='5',a='8',s='gap',note='ייתכן שתגית אחת מסמנת כמה לוחות על אותו קיר'),
  dict(g='נגרות',c='נ6',n='מתלה מעילים',e='2',a='4',s='gap'),
  dict(g='נגרות',c='נ7–נ9',n='כוורת, דלת 90/210, ארון שירותים',e='2 + 1 + 2',a='2 + 1 + 2',s='ok'),
  dict(g='מסגרות',c='מ1–מ3',n='דלת הדף, חלון הדף, צינור 4"',e='2 + 2 + 2',a='2 + 2 + 2',s='ok'),
  dict(g='מסגרות',c='מ4',n='צינור אוורור 8"',e='8',a='6',s='near',note='אותו צינור מתויג משני צידי הקיר. אחרי ניקוי כפילויות יוצא 6'),
  dict(g='מסגרות',c='מ6',n='חזית דלתות לגומחות',e='4',a='3',s='near',note='התגיות בתוך הממ"ד. ייתכן שהמספור בכתב שונה'),
  dict(g='מסגרות',c='מ13–מ16',n='סולם, מכסה גג, דלתות ארונות',e='1 + 1 + 2 + 2',a='1 + 1 + 2 + 2',s='ok'),
  dict(g='מסגרות',c='מ17',n='דלת ארון תקשורת',e='0',a='1',s='gap',note='לא נמצאה תגית'),
 ],
 masonry=[
  dict(n='בלוקים, כל הסוגים',u='מ"ר',e=325,a=280,b=353,note='משכבת הקירות של האוטוקאד, בגובה 3.55 ו-3.35 מ׳ מהחתך'),
  dict(n='מחיצות 10 ס"מ',u='מ"ר',e=130,a=110,b=118,note='כולל קטעים קצרים ליד משקופים שעוד לא סוננו'),
  dict(n='בלוקים 20 ופומיס חוץ, יחד',u='מ"ר',e=195,a=170,b=235,note='באותו עובי בשרטוט. ההפרדה ביניהם דורשת את סוג החומר'),
  dict(n='ריצוף, שתי קומות',u='מ"ר',e=284,a=245,b=268,note='ברוטו פחות קירות, מדרגות ופיר'),
 ],
 findings=[
  dict(sev='gap',t='קורות: 22.7 מ"ק בתוכניות, 35–37 בכתבים',d='21 הקורות שבגיליונות נמדדו בעומק מלא. אין קורה 3.5 במספור, אבל קורה אחת לא מסבירה פער כזה.',amt=18500,amtTxt='≈ 17,000–20,000 ₪',ch='בטון'),
  dict(sev='gap',t='ברזל: 18.3 טון זוהו, 28–30 בכתבים',d='עוד לא נקראו היסודות, המדרגות והרשת העליונה "לפי הנדרש". גם עם הפריטים האלה הסך צפוי להישאר נמוך מהכתבים.',amt=None,amtTxt='4,900–5,730 ₪ לטון',ch='ברזל'),
  dict(sev='near',t='יסוד משותף אלכסוני בין עמודים 2–3',d='6.4 מ"ק. לא ברור מהשרטוט אם הוא חדש או קיים. בלעדיו היסודות יוצאים 21.5 מ"ק, כמעט כמו בכתבים.',amt=None,amtTxt='6.4 מ"ק',ch='בטון'),
  dict(sev='near',t='תקרות 25 ס"מ: 323 מ"ר מול 275–305',d='כ-5 מ"ר הם קורות בולטות שנספרו כתקרה. את השאר צריך לברר מול אופני המדידה, למשל אם מנכים את רוחב הקורות.',amt=None,amtTxt='+6% עד +17%',ch='בטון'),
  dict(sev='gap',t='פריטים חסרים: א14, מ17, נ5, נ6',d='רפפת עשן ודלת ארון תקשורת לא מסומנות בתוכניות. לוחות תצוגה ומתלי מעילים: פחות תגיות מהכתב.',amt=None,amtTxt='4 פריטים',ch='אדריכלות'),
  dict(sev='info',t='יסודות קיימים לא נספרו',d='בגיליון ק-1 כמה יסודות מסומנים "יסוד קיים". המנוע השאיר אותם מחוץ לחישוב.',amt=None,amtTxt='3 יסודות',ch='בטון'),
 ],
 images=dict(struct='olga/img_struct.jpg',arch='olga/img_arch.jpg',beam='olga/img_beam.jpg'),
)
# ---------- HOFIM ----------
ps=json.load(open(H+'piles_summary.json'))
price={50:212,60:280,70:360}
piles=[dict(b=p['b'],dia=p['dia'],n=p['n'],read=p['read'],m=p['m12'],boq=p['boq'],per=round(p['boq']/p['n'],2),price=price[p['dia']]) for p in ps]
pile_gap=sum((p['boq']-p['m'])*p['price'] for p in piles)
hofim=dict(id='hofim',name='תיכון חופים',place='חדרה',client='החברה הכלכלית לפיתוח חדרה',
 docs='מכרז שלב ב׳+ג׳ · כתב כמויות באקסל',scale='1:75 · 1:50',
 sheets=dict(struct=67,arch=34),layers=dict(arch='אין',struct='26–42'),
 boq=dict(total=51686769,stageB=25085858,stageC=20201570,concB=7402411,rebarB_t=430),
 piles=piles,pile_gap=round(pile_gap),
 walls=[dict(n='קירות 25 ס"מ',e=82,a=80,s='ok'),dict(n='קירות 40 ס"מ',e=347,a=395,s='near',note='כולל 167 מ"ק קירות 45 ס"מ בגרעין המזרחי. בכתב אין סעיף 45'),
        dict(n='קירות 20 ס"מ',e=141,a=235,s='gap',note='כולל קירות המבנה על הגג, 340 ס"מ לפי התגיות W-01…W-04'),
        dict(n='קירות 35 ס"מ',e=66,a=145,s='gap'),dict(n='קירות 30 ו-95 ס"מ',e=7,a=45,s='gap'),
        dict(n='עמודים מלבניים ועגולים',e=77,a=107,s='gap',note='49 ו-28 מ"ק'),dict(n='קירות מסד',e=40,a=65,s='na',note='גובה של כמטר הוא הנחה')],
 slabs=[dict(n='פלטות חלולות טרומיות',e=879,a=1005,s='near',note='בעיקר 20 ו-30 ס"מ עם טופינג 6 ס"מ, ועוד כ-85 מ"ר טרומי 36 ו-75'),dict(n='תקרות 36 ס"מ',e=202,a=185,s='ok'),
        dict(n='תקרות 75 ס"מ',e=15,a=20,s='near'),dict(n='רצפות על הקרקע',e=1489,a=1760,s='near',note='20, 25 ו-30 ס"מ, כולל רצפת האולם'),
        dict(n='תקרות וגגות 20 ס"מ',e=1679,a=2585,s='gap',note='בכתב: 1,570 שטוחות ועוד 1,015 גג משופע'),dict(n='תקרות 30 ס"מ',e=559,a=900,s='gap'),
        dict(n='גג קשתי 17 ס"מ',e=0,a=425,s='gap',note='לא נמצא בתוכניות'),dict(n='גגות משופעים 25 ו-35 ס"מ',e=None,a=255,s='na',note='המנוע עוד לא מזהה שיפוע'),
        dict(n='תקרות 40 ס"מ',e=184,a=None,s='na',note='בתוכניות יש, בכתב אין סעיף'),dict(n='תקרות 15 ס"מ',e=8,a=None,s='na',note='בגג המבנה העליון')],
 rebar=[dict(n='קורות',read=30,tot='47',totv=47,cov='85%',note='12 גיליונות פרטי קורות'),dict(n='תקרות ורצפות',read=71,tot='99',totv=99,cov='524 מתוך 740',note='11 גיליונות זיון עליון ותחתון. גיליון 540 זהה ל-530 ולא נספר פעמיים'),
        dict(n='קירות ועמודים',read=29,tot='45–61',totv=53,cov='885 מתוך 1,073',note='5 גיליונות זיון אנכי')],
 rebar_boq=430,
 roofs=dict(engine=1660,boq=1630),
 findings=[
  dict(sev='gap',t='ברזל: כ-190–205 טון בתוכניות, 430 בכתב',d='כ-2,400 תוויות ברזל נקראו מהשרטוטים. ביחס לנפח הבטון זה כ-90–95 ק"ג למ"ק, כמו באולגה. הכתב מניח כ-140.',amt=1400000,amtTxt='≈ 1.4–1.5 מיליון ₪',ch='ברזל'),
  dict(sev='gap',t='תקרות: 3,527 מ"ר בתוכניות, 5,375 בכתב',d='900 מ"ר גג תלול ו-425 מ"ר גג קשתי לא נמצאו בתוכניות. פרק האיטום של אותו כתב מסכים עם המנוע: כל הגגות שטוחים.',amt=690000,amtTxt='≈ 690,000 ₪',ch='בטון'),
  dict(sev='gap',t='קירות ועמודים: 720 מ"ק מול 1,007',d='קירות 25 ו-40 ס"מ קרובים לכתב. הפער בקירות 20 ו-35 ס"מ ובעמודים. גם בגובה מרצפה לרצפה נשאר כ-20%.',amt=410000,amtTxt='≈ 410,000 ₪',ch='בטון'),
  dict(sev='near',t='כלונסאות: 13.2 מ׳ לכלונס בכתב, 12 מ׳ בתוכנית',d=f'348 כלונסאות נספרו. בכל הקטרים הכתב מוסיף 1.0–1.5 מ׳ לכלונס, בממוצע 1.2, והמפרט לא מגדיר את התוספת.',amt=round(pile_gap),amtTxt=f'≈ {round(pile_gap,-3):,.0f} ₪',ch='כלונסאות'),
  dict(sev='gap',t='סעיף "עומק עד 10 מ׳" לכלונסאות של 12 מ׳',d='סעיפי Ø50 ו-Ø60 מוגדרים לעומק עד 10 מ׳. כל הכלונסאות בתוכניות באורך 12 מ׳. בסיס אפשרי לדרישת מחיר אחר.',amt=None,amtTxt='4,150 מ׳',ch='כלונסאות'),
  dict(sev='info',t='פרקי הגמר תואמים למדידה',d='גגות 1,660 מ"ר במנוע מול 1,630 בפרק האיטום. ריצוף כ-3,300 מ"ר מתאים לשטח הקומות. הפער מרוכז בפרק הבטון.',amt=None,amtTxt='1,660 מול 1,630',ch='בדיקה'),
 ],
 images=dict(pB='hofim/ov_B110.jpg',pC='hofim/ov_C110.jpg',walls='hofim/fig_walls_220.jpg',slab='hofim/fig_slab_220.jpg',ocr='hofim/fig_ocr230.jpg'),
)

# ---------- FINISHES (Olga) ----------
fin=json.load(open(f'{S}/olga/finishes.json'))
olga['finishes']=dict(face=fin['face'],wet_per=fin['wet_per'],wing_per=fin['wing_per'],floor_free=329.5,gyps=136.6,acou=98,flooring=284,
  defaults=dict(H=2.9,Ht=2.6,Hb=8.3,ext_open=92,doors=12),
  boq=dict(plaster=[450,508],tile=[50,91],paint=[400,465],skirt=[180,161],ext=[410,321],gyps=[150,144],acou=[120,128],floor=[361,268],ceilpaint=[245,None]),
  price=dict(plaster=97,tile=236,paint=28.5,skirt=43,ext=127,gyps=213,acou=171,floor=230,ceilpaint=28))
olga['findings']+= [
  dict(sev='under',t='חיפוי בשירותים: 178 מ"ר בתוכניות, 50–91 בכתבים',d='היקף חדרי השירותים 71 מ׳. המפרט קובע חיפוי לגובה 2.60 מ׳, כלומר כ-178 מ"ר אחרי ניכוי הדלתות. הכתבים כוללים רק חצי מזה או פחות, ולכן צפויה דרישת תוספת.',amt=20500,amtTxt='≈ 20,500 ₪ חסרים',ch='גמרים'),
  dict(sev='check',t='טיח פנים וצבע: התוכניות גבוהות מהכתב',d='לפי 354 מ׳ פני קיר וגובה 2.9 מ׳ יוצאים כ-890 מ"ר טיח, מול 450–508 בכתבים. התוצאה תלויה בגובה ובקירות הבטון שנשארים גלויים. נדרש מקרא הגמרים.',amt=None,amtTxt='עד ≈ 37,000 ₪',ch='גמרים'),
  dict(sev='info',t='תקרות, ריצוף וטיח חוץ תואמים',d='תקרת גבס 137 מ"ר מול 144–150. ריצוף 284 מול 268 באומדן 2021. טיח חוץ 366 בין שני הכתבים.',amt=None,amtTxt='137 מול 144–150',ch='גמרים'),
]
# ---------- BOQ CHAPTERS ----------
def chapters(items,keyf,namef):
    out={}
    for i in items:
        k=keyf(i)
        if k is None: continue
        o=out.setdefault(k,dict(code=k,n=namef(i,k),v=0,cnt=0)); o['v']+=i.get('total') or 0; o['cnt']+=1
    return sorted(out.values(),key=lambda x:-x['v'])
COV_O={'02':('full','בטון','concrete'),'04':('full','בנייה','arch'),'09':('full','גמרים','finish'),'10':('full','גמרים','finish'),'11':('full','גמרים','finish'),
       '12':('full','פריטים','arch'),'06':('part','פריטים','arch'),'19':('part','פריטים','arch'),'22':('part','גמרים','finish')}
oc=chapters([i for i in o20 if i['struct'].startswith('01')],lambda i:i['code'][:2],lambda i,k:i['chapter'][3:].strip() or ('פיתוח, חפירה כללית' if k=='40' else ''))
for c in oc: c['cov'],c['mod'],c['tab']=COV_O.get(c['code'],('none','',''))
olga['chapters']=oc; olga['chapters_scope']='כתב 2020 · מבנה הגן, ללא פיתוח'
COV_H={'02':('full','בטון וברזל','concrete'),'03':('full','טרומי','concrete'),'23':('full','כלונסאות','piles'),'05':('check','גגות','concrete'),'10':('check','ריצוף','concrete')}
hb=json.load(open(f'{H}boq.json'))
hc=chapters([i for i in hb['items'] if i['code'].startswith('01.')],lambda i:i['code'].split('.')[1],lambda i,k:hb['heads'].get('01.'+k,''))
for c in hc: c['cov'],c['mod'],c['tab']=COV_H.get(c['code'],('none','',''))
hofim['chapters']=hc; hofim['chapters_scope']='שלב ב׳ · מבנה, ללא פיתוח'
olga['images'].update(ceil='olga/fig_ceil.jpg',faces='olga/fig_faces.jpg')
hofim['gap_total']=sum(f['amt'] or 0 for f in hofim['findings'] if f['sev'] in('gap','near'))
olga['gap_total']=sum(f['amt'] or 0 for f in olga['findings'] if f['sev'] in('gap','near'))
for pr in (olga,hofim): pr['under_total']=sum(f['amt'] or 0 for f in pr['findings'] if f['sev']=='under')
data=dict(projects=[olga,hofim],stats=dict(labels=2400,sheets=14+6+67+34))
json.dump(data,open('/home/claude/system/data.json','w'),ensure_ascii=False,indent=1)
print('pile_gap',round(pile_gap),'hofim gap',hofim['gap_total'],'olga gap',olga['gap_total'])
print('olga boq',olga['boq'])
