import sys, json, numpy as np
sys.path.insert(0,'/tmp/claude-0/-home-claude/90f9075a-8e8a-5948-8a8e-80f1167be059/scratchpad/scripts')
import hofim_walls as HW
O=HW.OUT; res=json.load(open(O+'walls_raw.json'))
for sh in sys.argv[1:]:
    S,H,Hl,dn,up=HW.plan(sh)
    cs,_=HW.comps(S,'solid'); ch,_=HW.comps(H,'hatch',Hl,dn,up)
    np.save(O+f'S_{sh}.npy',np.packbits(S)); np.save(O+f'H_{sh}.npy',np.packbits(H))
    res[sh]=dict(shape=S.shape,solid=cs,hatch=ch)
    print(sh,"solid",len(cs),round(sum(c['area'] for c in cs),2),"hatch",len(ch),round(sum(c['area'] for c in ch),2),
      "hatch dens>=.55",round(sum(c['area'] for c in ch if c['dens']>=0.55),2))
    json.dump(res,open(O+'walls_raw.json','w'),default=lambda o: o.item() if hasattr(o,'item') else o)
