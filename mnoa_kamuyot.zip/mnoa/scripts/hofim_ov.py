import json, numpy as np, sys
from PIL import Image, ImageDraw
from scipy import ndimage as ndi
O='/tmp/claude-0/-home-claude/90f9075a-8e8a-5948-8a8e-80f1167be059/scratchpad/hofim/'
R=json.load(open(O+'walls_raw.json')); W=json.load(open(O+'walls_vol.json'))
sh=sys.argv[1]
def load(n): 
    shp=tuple(R[sh]['shape']); return np.unpackbits(np.load(O+f'{n}_{sh}.npy'))[:shp[0]*shp[1]].reshape(shp).astype(bool)
Sm,Hm=load('S'),load('H')
rgb=np.full(Sm.shape+(3,),255,np.uint8); rgb[Sm|Hm]=(200,200,200)
COL={'wall_20':(46,125,79),'wall_25':(120,170,60),'wall_30':(200,170,0),'wall_35':(230,120,0),'wall_40':(200,50,40),'wall_45':(150,30,120),'wall_60':(80,40,160),'wall_95':(0,0,0),'col_rect':(25,90,170),'col_round':(0,160,200)}
for it in W['items']:
    if it['sh']!=sh: continue
    y0,y1,x0,x1=it['sl']; m=(Sm if it['kind']=='solid' else Hm)[y0:y1,x0:x1]
    k=it['k'].replace('found_','')
    rgb[y0:y1,x0:x1][m]=COL.get(k,(0,0,0)) if it['h']!=7.3 else (255,0,255)
im=Image.fromarray(rgb); im.thumbnail((1600,1600)); im.save(O+f'cls_{sh}.png')
