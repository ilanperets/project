import fitz,sys,numpy as np,cv2
src,out,x0,y0,x1,y1=sys.argv[1],sys.argv[2],*map(float,sys.argv[3:7])
d=fitz.open(src); p=d[0]; dr=p.get_drawings()
LAY={'IZ  wall-0.6':(0,0,0),'IZ  hatch-0.1':(0,160,0),'IZ בלוקים אדום':(0,0,230),'BET':(150,150,150),'MAMAD 0.2':(200,0,200),'IZ  win':(230,120,0),'IZ  win-0.3':(230,160,60),'0':(0,200,230),'IZ  0.2':(120,60,0)}
s=1.2; W=int((x1-x0)*s); H=int((y1-y0)*s)
img=np.full((H,W,3),255,np.uint8)
def P(pt): return (int((pt.x-x0)*s),int((pt.y-y0)*s))
for x in dr:
    c=LAY.get(x.get('layer'))
    if c is None: continue
    for it in x['items']:
        if it[0]=='l': cv2.line(img,P(it[1]),P(it[2]),c,1)
        elif it[0]=='re':
            r=it[1]; cv2.rectangle(img,P(r.tl),P(r.br),c,1)
        elif it[0]=='qu':
            q=it[1]; pts=np.array([P(q.ul),P(q.ur),P(q.lr),P(q.ll)],np.int32); cv2.polylines(img,[pts],True,c,1)
        elif it[0]=='c': cv2.line(img,P(it[1]),P(it[4]),c,1)
    if x.get('fill') and x.get('layer') in ('BET','MAMAD 0.2','IZ בלוקים אדום','IZ  hatch-0.1'):
        pass
cv2.imwrite(out,img)
# legend print
import collections
