import openpyxl, json, re, sys
wb=openpyxl.load_workbook(sys.argv[1],data_only=True); ws=wb.worksheets[0]
items=[]; heads={}
for r in ws.iter_rows(min_row=1,values_only=True):
    r=list(r)+[None]*7
    code,desc,unit,qty,price,tot=[r[i] for i in range(6)]
    if code and isinstance(code,str) and re.fullmatch(r'\d{2}(\.\d{2,3})*',code.strip()):
        heads[code.strip()]=desc
    elif code and isinstance(code,str) and re.fullmatch(r'\d{2}\.\d{2}\.\d{3}\.\d{4}',code.strip()) and qty not in (None,''):
        items.append(dict(code=code.strip(),desc=str(desc).strip(),unit=unit,qty=qty,price=price,total=tot))
json.dump(dict(heads=heads,items=items),open(sys.argv[2],'w'),ensure_ascii=False,indent=0)
print(len(items),"items")
for k,v in heads.items():
    if k.count('.')<=1:
        tot=sum((i['total'] or 0) for i in items if i['code'].startswith(k+'.'))
        print(k, v, f"{tot:,.0f}")
