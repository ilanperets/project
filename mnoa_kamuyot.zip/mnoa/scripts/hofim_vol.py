import json, numpy as np, collections, sys, math
sys.path.insert(0,'/tmp/claude-0/-home-claude/90f9075a-8e8a-5948-8a8e-80f1167be059/scratchpad/scripts')
from scipy import ndimage as ndi
O='/tmp/claude-0/-home-claude/90f9075a-8e8a-5948-8a8e-80f1167be059/scratchpad/hofim/'
R=json.load(open(O+'walls_raw.json'))
CLS=[20,25,30,35,40,45,60,95]
def load(n,sh): 
    shp=tuple(R[sh]['shape']); return np.unpackbits(np.load(O+f'{n}_{sh}.npy'))[:shp[0]*shp[1]].reshape(shp).astype(bool)
def ok(c):
    if c['kind']=='hatch':
        if c['dens']<0.55 or c['fu']>0.6: return False
    return c['t']>=14 and c['spread']<=0.9
def cls(c):
    h,w=c['bb']; asp=max(h,w)/max(1,min(h,w))
    if c['L']<1.3 and c['area']<1.0:
        roundish=asp<1.25 and abs(c['area']-math.pi*(max(h,w)/200)**2)<0.2*c['area']
        return 'col_round' if roundish else 'col_rect'
    return 'wall_%d'%min(CLS,key=lambda x:abs(x-c['t']))
m20=ndi.binary_closing(load('S','020')|load('H','020'),structure=np.ones((25,25)))
lab20,_=ndi.label(m20); sz=ndi.sum(m20,lab20,range(1,lab20.max()+1)); big=np.argmax(sz)+1
pit=ndi.binary_dilation(ndi.binary_fill_holes(lab20==big),iterations=40)
H={'220':4.0,'320':3.6,'420':3.55,'520':3.4}
vol=collections.defaultdict(float); per=collections.defaultdict(lambda:collections.defaultdict(float)); items=[]
for sh,h in H.items():
    labS,_=ndi.label(load('S',sh)); labH,_=ndi.label(load('H',sh))
    for kind,lab in (('solid',labS),('hatch',labH)):
        for c in R[sh][kind]:
            if not ok(c): continue
            k=cls(c); hh=h
            v=c['area']*hh; vol[k]+=v; per[sh][k]+=v
            items.append(dict(sh=sh,k=k,area=c['area'],h=hh,v=v,t=c['t'],sl=c['sl'],kind=kind))
# foundation walls: solid in 120 that stop at ground slab
fw=collections.defaultdict(float); bs=collections.defaultdict(float)
labS,_=ndi.label(load('S','120')); labH,_=ndi.label(load('H','120'))
for kind,lab in (('solid',labS),('hatch',labH)):
  for c in R['120'][kind]:
    if not ok(c): continue
    k=cls(c); m=lab==c['i']; inpit=(m&pit).sum()>0.5*m.sum()
    hh=3.2 if inpit else 1.0
    (bs if inpit else fw)[k]+=c['area']*hh
    items.append(dict(sh='120',k=('base_' if inpit else 'found_')+k,area=c['area'],h=hh,v=c['area']*hh,t=c['t'],sl=c['sl'],kind=kind))
print("basement (pit) 120",{k:round(v,1) for k,v in bs.items()}, round(sum(bs.values()),1))
print({k:round(v,1) for k,v in sorted(vol.items())}, "total",round(sum(vol.values()),1))
for sh in H: print(sh,{k:round(v,1) for k,v in sorted(per[sh].items())})
print("foundation walls",{k:round(v,1) for k,v in fw.items()})

json.dump(dict(vol=vol,per=per,fw=fw,bs=bs,items=items),open(O+'walls_vol.json','w'))
