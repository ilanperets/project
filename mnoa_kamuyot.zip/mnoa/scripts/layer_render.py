import pymupdf as fitz, sys
def replay(path, layers, out_pdf=None):
    src=fitz.open(path)[0]
    nd=fitz.open(); pg=nd.new_page(width=src.mediabox.width,height=src.mediabox.height)
    sh=pg.new_shape()
    for d in src.get_drawings():
        if d.get('layer') not in layers: continue
        for it in d['items']:
            k=it[0]
            if k=='l': sh.draw_line(it[1],it[2])
            elif k=='c': sh.draw_bezier(it[1],it[2],it[3],it[4])
            elif k=='re': sh.draw_rect(it[1])
            elif k=='qu': sh.draw_quad(it[1])
        sh.finish(color=(0,0,0),width=max(0.6,(d.get('width') or 0.5)),fill=None, closePath=False)
    sh.commit()
    return nd, pg
def render_layers(path, layers, dpi, out, clip=None):
    nd,pg=replay(path,layers)
    pix=pg.get_pixmap(dpi=dpi,clip=clip,colorspace=fitz.csGRAY); pix.save(out); return pg.rect,pix
if __name__=="__main__":
    r,p=render_layers(sys.argv[1], sys.argv[2].split(','), int(sys.argv[3]), sys.argv[4]); print(r,p.width,p.height)
