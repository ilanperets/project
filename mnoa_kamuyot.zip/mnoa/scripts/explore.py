import json,sys,collections,re
db=json.load(open(sys.argv[1]))
h=db['header']; print('INSUNITS',h.get('INSUNITS'), 'EXTMIN',h.get('EXTMIN'),'EXTMAX',h.get('EXTMAX'))
E=db['entities']
print('sample keys', {t:list(next(e for e in E if e['type']==t).keys()) for t in ['LINE','INSERT','MTEXT','HATCH']})
ins=collections.Counter((e['layer'],e.get('name')) for e in E if e['type']=='INSERT')
print('\nINSERTs by layer/block:'); [print(' ',c,k) for k,c in ins.most_common(60)]
print('\nMTEXT by layer:')
mt=collections.defaultdict(list)
for e in E:
  if e['type']=='MTEXT': mt[e['layer']].append(e.get('text'))
for L,v in mt.items(): print(' ',L,len(v), v[:25])
