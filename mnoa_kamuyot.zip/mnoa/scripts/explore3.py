import json,sys,collections,re
db=json.load(open(sys.argv[1])); E=[e for e in db['entities'] if e['ownerBlockRecordSoftId']=='70']
clean=lambda t: re.sub(r'\\f[^;]*;','',t or '').replace('\\P',' ').strip()
a=[(round(e['insertionPoint']['x']),round(e['insertionPoint']['y']),clean(e['text'])) for e in E if e['type']=='MTEXT' and e['layer']=='A-AREA-IDEN']
print(a)
print('edge types', collections.Counter(p.get('boundaryPathTypeFlag') for e in E if e['type']=='HATCH' for p in e['boundaryPaths']))
fp=[e for e in E if e['type']=='HATCH' and e['layer']=='A-FLOR-PATT']
print(json.dumps(fp[0]['boundaryPaths'])[:600]); print(fp[0]['patternScale'], fp[0]['definitionLines'][:2] if fp[0].get('definitionLines') else None)
print('cols', collections.Counter(e['type'] for e in E if e['layer']=='S-COLS'))
print('AFLOR', collections.Counter(e['type'] for e in E if e['layer']=='A-FLOR'))
print('IWALL', collections.Counter(e['type'] for e in E if e['layer']=='I-WALL'), 'AWALL',collections.Counter(e['type'] for e in E if e['layer']=='A-WALL'))
