import sys, re, json, math
import pymupdf as fitz, pytesseract
from PIL import Image
TL=('BarsTitle','SectBarTxt','LinkDimTxt','S_BAR_TAG','TXT','S_TEXT1','S_TEXT')
def filtered(src, layers):
    dr=[d for d in src.get_drawings() if d['layer'] in layers]
    # find circles: path with 2 'c' items forming half-ellipses: pair them by rect
    rm=set(); circles=[]; phis=[]
    for i,d in enumerate(dr):
        k="".join(it[0] for it in d['items']); r=d['rect']
        if k=='cc':
            big=max(r.width,r.height); small=min(r.width,r.height)
            if big>10: circles.append(r); rm.add(i)
            elif 5.5<big<7.5 and 2.5<small<4: phis.append(r); rm.add(i)
    for i,d in enumerate(dr):
        if i in rm: continue
        r=d['rect']; c=fitz.Point((r.x0+r.x1)/2,(r.y0+r.y1)/2)
        for C in circles:
            if C.contains(c) and r.width<C.width and r.height<C.height: rm.add(i); break
        else:
            for P in phis:
                PP=fitz.Rect(P.x0-2,P.y0-2,P.x1+2,P.y1+2)
                if PP.contains(c) and len(d['items'])<=2: rm.add(i); break
    nd=fitz.open(); pg=nd.new_page(width=src.mediabox.width,height=src.mediabox.height)
    sh=pg.new_shape()
    for i,d in enumerate(dr):
        if i in rm: continue
        for it in d['items']:
            if it[0]=='l': sh.draw_line(it[1],it[2])
            elif it[0]=='c': sh.draw_bezier(*it[1:5])
            elif it[0]=='re': sh.draw_rect(it[1])
            elif it[0]=='qu': sh.draw_quad(it[1])
        sh.finish(color=(0,0,0),width=0.7)
    # mark positions of phis (as spacer) -> nothing
    sh.commit(); pg.set_rotation(src.rotation)
    return nd,pg,len(circles),len(phis)
def ocr(pg, dpi=300):
    pix=pg.get_pixmap(dpi=dpi,colorspace=fitz.csGRAY)
    im=Image.frombytes("L",[pix.width,pix.height],pix.samples)
    W,H=im.size; out=[]
    for rot in (0,90,-90):
        r=im if rot==0 else im.rotate(rot,expand=True)
        d=pytesseract.image_to_data(r,config='--psm 11',output_type=pytesseract.Output.DICT)
        # group into lines by block/par/line
        lines={}
        for i,t in enumerate(d['text']):
            t=t.strip()
            if not t: continue
            key=(d['block_num'][i],d['par_num'][i],d['line_num'][i])
            lines.setdefault(key,[]).append((d['left'][i],t,d['top'][i],d['height'][i]))
        for k,ws in lines.items():
            ws.sort(); txt=" ".join(w[1] for w in ws)
            u=ws[0][0]; v=ws[0][2]+ws[0][3]/2
            out.append((txt,rot,u,v))
    return out,im.size
if __name__=="__main__":
    src=fitz.open(sys.argv[1])[0]
    nd,pg,nc,nphi=filtered(src,TL)
    print("circles",nc,"phis",nphi, "rot",src.rotation)
    if len(sys.argv)>3:
        R=[float(x) for x in sys.argv[3].split(',')]
        pg.get_pixmap(clip=fitz.Rect(*R),dpi=150).save(sys.argv[2]+'.png')
    lines,size=ocr(pg)
    json.dump(lines,open(sys.argv[2],'w'))
    print(len(lines)); print([l[0] for l in lines][:80])
