import pymupdf as fitz, sys, math, numpy as np, json
from PIL import Image, ImageDraw
from scipy import ndimage as ndi
CM=2.0  # cm per px
def masks(pdf, scale):
    pg=fitz.open(pdf)[0]; M=pg.rotation_matrix
    k=(1/(scale*0.03528))*  (1/ (CM/1))  # px per pt  = (pt->cm)/CM
    k=scale*0.03528/CM
    W,H=int(pg.rect.width*k)+2,int(pg.rect.height*k)+2
    ims={n:Image.new("L",(W,H),0) for n in ('solid','hatch','down','up','conc')}
    dr={n:ImageDraw.Draw(i) for n,i in ims.items()}
    P=lambda p:((p*M).x*k,(p*M).y*k)
    for d in pg.get_drawings():
        L=d['layer']; its=d['items']
        if L=='s-solid' and 'f' in d['type']:
            pts=[]
            for it in its:
                if it[0]=='l': pts+=[P(it[1]),P(it[2])]
                elif it[0]=='c': pts+=[P(it[1]),P(it[2]),P(it[3]),P(it[4])]
                elif it[0]=='re': r=it[1]; dr['solid'].polygon([P(r.tl),P(r.tr),P(r.br),P(r.bl)],fill=255)
                elif it[0]=='qu': q=it[1]; dr['solid'].polygon([P(q.ul),P(q.ur),P(q.lr),P(q.ll)],fill=255)
            if len(pts)>=3: dr['solid'].polygon(pts,fill=255)
        elif L=='S_HATCH' and d['type']=='s' and round(d.get('width') or 0,2)==0.36:
            for it in its:
                if it[0]=='l' and abs(it[2]-it[1])>=2:
                    dr['hatch'].line([P(it[1]),P(it[2])],fill=255,width=2)
                elif it[0]=='l': dr['conc'].line([P(it[1]),P(it[2])],fill=255,width=2)
        elif L=='S_HATCH' and 'f' in d['type']:
            r=d['rect']; dr['conc'].ellipse([P(r.tl)[0]-1,P(r.tl)[1]-1,P(r.tl)[0]+1,P(r.tl)[1]+1],fill=255)
        elif L in('s_wall_DOWN','S_WALL_UP'):
            n='down' if L=='s_wall_DOWN' else 'up'
            for it in its:
                if it[0]=='l': dr[n].line([P(it[1]),P(it[2])],fill=255,width=1)
                elif it[0]=='c': dr[n].line([P(it[1]),P(it[4])],fill=255,width=1)
                elif it[0]=='re': r=it[1]; dr[n].rectangle([*P(r.tl),*P(r.br)],outline=255)
    A={n:np.array(i)>0 for n,i in ims.items()}
    return A,k,pg
def regions(A):
    h=ndi.binary_closing(A['hatch'],structure=np.ones((7,7)),iterations=1)
    h=ndi.binary_opening(h,structure=np.ones((3,3)))
    return h
if __name__=="__main__":
    pdf,scale,out=sys.argv[1],float(sys.argv[2]),sys.argv[3]
    A,k,pg=masks(pdf,scale)
    h=regions(A)
    lab,n=ndi.label(h)
    dn=ndi.binary_dilation(A['down'],iterations=2); up=ndi.binary_dilation(A['up'],iterations=2)
    rows=[]
    for i,sl in enumerate(ndi.find_objects(lab),1):
        m=lab[sl]==i; area=m.sum()*CM*CM/1e4
        if area<0.02: continue
        b=m ^ ndi.binary_erosion(m,iterations=2)
        fd=(b & dn[sl]).sum()/max(1,b.sum()); fu=(b & up[sl]).sum()/max(1,b.sum())
        rows.append((i,round(area,3),round(fd,2),round(fu,2)))
    sol=A['solid'].sum()*CM*CM/1e4
    print("solid m2",round(sol,2),"hatch comps",len(rows),"hatch m2",round(sum(r[1] for r in rows),2))
    print(" down-dominant",round(sum(r[1] for r in rows if r[2]>r[3]),2)," up-dominant",round(sum(r[1] for r in rows if r[3]>=r[2] and r[3]>0),2)," none",round(sum(r[1] for r in rows if r[2]==0 and r[3]==0),2))
    rgb=np.full(h.shape+(3,),255,np.uint8)
    rgb[A['solid']]=(220,60,50)
    for i,a,fd,fu in rows:
        rgb[lab==i]=(40,150,70) if fd>fu else ((240,150,0) if fu>0 else (60,110,220))
    Image.fromarray(rgb).save(out)
    json.dump(rows,open(out+'.json','w'))
