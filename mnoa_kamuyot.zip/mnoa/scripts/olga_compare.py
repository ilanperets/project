import json
# ---- engine values (from extraction scripts; see olga_struct/slab3/ring/open outputs)
o=json.load(open('olga/outline.json')); st=json.load(open('olga/struct.json'))
mmd=6.60*4.11            # safe-room block outer bbox (two outlined wall parts union) m2
elev_out=2.10*2.26; elev_in=1.70*1.965 if False else 3.34
stair=4.80*2.60          # tread cluster x1827-2157 + landing to inner wall, y between walls
g2=o['ק-2']['outline_m2']; s3=o['ק-3']['outline_m2']; r4=o['ק-4']['outline_m2']
E={}
E['רצפה 20 ס"מ (מ"ר)']=g2-elev_in-mmd
E['רצפה 25 ס"מ ממ"ד (מ"ר)']=mmd
E['תקרות 25 ס"מ (מ"ר)']=(s3-stair-elev_in)+(r4-mmd-elev_out)
E['תקרה 40 ס"מ ממ"ד (מ"ר)']=mmd
E['תקרה 20 ס"מ (מ"ר)']=elev_out
w3=st['ק-3']['wall_area']; up_mmd=3.205+2.720; up_elev=1.392; up_oth=1.392+0.337+0.079
walls_gf=w3*3.55; walls_up=up_mmd*3.20+up_elev*3.95+up_oth*3.35
E['קירות בטון מעל הרצפה (מ"ק)']=walls_gf+walls_up
E['קירות מתחת לרצפה (מ"ר בתוכנית)']=st['ק-2']['wall_area']
for k,v in E.items(): print(f'{k:32} {v:8.1f}')
print('detail: walls ground',round(walls_gf,1),'upper',round(walls_up,1),'| slab +3.65 net',round(s3-stair-elev_in,1),'roof 25 net',round(r4-mmd-elev_out,1))
# ---- implied rebar ratios
def vol(items):
    v=0
    for i in items:
        if not (i['struct'] or '').startswith('01') or not i['unit'] or not (i['chapter'] or '').startswith('02'): continue
        d=i['desc']
        if i['unit']=='מ"ק' and 'שיפוע' not in d and 'תוספת' not in d: v+=i['qty']
        elif i['unit']=='מ"ר':
            import re
            m=re.search(r'עובי\s*(\d+)\s*ס"מ',d) or re.search(r'(\d+)\s*ס"מ',d)
            if m and any(w in d for w in ['תקר','מרצפ','משטח']): v+=i['qty']*int(m.group(1))/100
    return v
for fn,ton in [('olga2020.json',28),('olga2021.json',30)]:
    it=json.load(open(fn)); V=vol(it); print(fn,'concrete m3 ≈',round(V,1),'rebar kg/m3 ≈',round(ton*1000/V))
