import json
W=lambda d:0.00617*d*d
sr=json.load(open('olga/slab_rebar.json'))
# ---- concrete (m3) from engine
found={'pad 18 120/120/50':1.2*1.2*0.5,'rotated footing 2-3 (442x240x60)':4.42*2.40*0.60,
       'safe-room strips d=50':(7.42*5.02-1.60*1.44-3.45*2.55)*0.5,'strip 16-17 80/50':7.39*0.80*0.50,'elevator pit slab 335/320/45':3.35*3.20*0.45}
F=sum(found.values())
below_walls=6.357*0.55+1.378*1.35+1.419*0.55+0.338*0.55
walls=64.0+below_walls
beams_full=22.68; beams_below=16.90
slab20=158.0; mmd=24.8; s25=323.0; s20top=4.7
conc={'יסודות':F,'רצפה 20':slab20*0.20,'רצפת ממ"ד 25':mmd*0.25,'קירות':walls,'קורות (עומק מלא)':beams_full,'תקרות 25':s25*0.25,'תקרת ממ"ד 40':mmd*0.40,'תקרה 20':s20top*0.20}
for k,v in found.items(): print(f'  {k:36} {v:6.2f}')
print('foundations',round(F,1),'| walls below slab',round(below_walls,1),'| walls total',round(walls,1))
TOT=sum(conc.values()); print('concrete total (engine)',round(TOT,1))
# ---- rebar (kg)
mmd_wall_len=5.925/0.32; mmd_wall_area=mmd_wall_len*7.35-2*2.6
mmd_rebar= mmd_wall_area*(2*10*W(10)+2*5*W(10))*1.10 + mmd*(4*10*W(10)) + mmd*(2*10*W(10)+2*5*W(10)) + 2*45*3.75*W(16)
roof=157.8*sr['kgm2']
other_cols=2*74*3.55*W(16)*1.2
reb={'קורות (נקרא מהתוכנית)':2810,'רצפה −0.15 (נקרא)':sr['g'],'תקרה +3.65 (נקרא)':sr['s365'],
     'גג +7.25 (הערכה לפי ק"ג/מ"ר של +3.65)':roof,'ממ"ד (רשתות × שטחים)':mmd_rebar,'עמודים וקצוות קירות (תוויות)':other_cols}
for k,v in reb.items(): print(f'  {k:42} {v/1000:5.2f} t')
R=sum(reb.values()); print('rebar so far',round(R/1000,1),'t  ->  kg/m3',round(R/TOT))
json.dump(dict(conc=conc,TOT=TOT,reb=reb,R=R,F=F,walls=walls),open('olga/ch02.json','w'),ensure_ascii=False)
