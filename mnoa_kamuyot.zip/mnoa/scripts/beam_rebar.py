import sys, pickle, json, re, numpy as np, collections
sys.path.insert(0,'/tmp/claude-0/-home-claude/90f9075a-8e8a-5948-8a8e-80f1167be059/scratchpad/scripts')
import glyphs as G
O='/tmp/claude-0/-home-claude/90f9075a-8e8a-5948-8a8e-80f1167be059/scratchpad/hofim/'
BD="/tmp/claude-0/-home-claude/90f9075a-8e8a-5948-8a8e-80f1167be059/scratchpad/corpus/hadera/T1222_hofim_highschool/קונסטרוקציה מבנה B_x/קונסטלציה מבנה B/מבנה B/CONST_B_%s.pdf"
P,_=pickle.load(open(O+'cl250.pkl','rb')); L=json.load(open(O+'labels250_id.json'))
FIX={'Z':'5','ß':'3'}
def norm(s):
    for k,v in FIX.items(): s=s.replace(k,v)
    return s
W=lambda d:0.00617*d*d
def run(sh, layers=('BarsTitle','SectBarTxt','LinkDimTxt')):
    a=G.render(BD%sh,layers)
    cs,_=G.comps(a)
    for c in cs:
        if c['kind']=='g':
            h=c['y1']-c['y0']; w=c['x1']-c['x0']
            c['cl']=-2 if (h>48 and w>48) else None
    G.classify(cs,P,L,thr=22)
    ls=[(norm(t),x,y) for t,x,y in G.lines(cs)]
    return ls
MAIN=re.compile(r'(\d{1,2})\s*Φ\s*w?\s*(\d{1,2})\s*L\s*=\s*(\d{2,4})')
STIR=re.compile(r'(\d{1,3})\s*Φ\s*w?\s*(\d{1,2})\s*@\s*(\d{1,2})')
LONLY=re.compile(r'^[#?\s]*L\s*=\s*(\d{2,4})\s*$')
if __name__=="__main__":
    res={}
    for sh in sys.argv[1:]:
        ls=run(sh)
        main=[];stir=[];lonly=[]
        for t,x,y in ls:
            m=MAIN.search(t)
            if m:
                n,d,Lc=map(int,m.groups())
                if d in (8,10,12,14,16,18,20,22,25,28,32) and 30<=Lc<=2500 and n<=40: main.append((n,d,Lc,t))
                continue
            m=STIR.search(t)
            if m:
                n,d,s=map(int,m.groups())
                if d in (8,10,12) and n>=2: stir.append((n,d,s,t))
                continue
            m=LONLY.match(t)
            if m: lonly.append(int(m.group(1)))
        kg=sum(n*Lc/100*W(d) for n,d,Lc,_ in main)
        ns=sum(n for n,_,_,_ in stir)
        res[sh]=dict(lines=len(ls),main=len(main),kg_main=kg,stir_sets=len(stir),stir_n=ns,stir_d=collections.Counter(d for _,d,_,_ in stir),lonly=lonly,mains=main,stirs=stir)
        print(sh,"lines",len(ls),"main",len(main),f"kg {kg:,.0f}","stir sets",len(stir),"n",ns,"Lonly",len(lonly),"meanL",round(np.mean(lonly),0) if lonly else None)
    pickle.dump(res,open(O+'beam_rebar.pkl','wb'))
