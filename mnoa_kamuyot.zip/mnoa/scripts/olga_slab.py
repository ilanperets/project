import pdfplumber,sys,numpy as np,cv2,math,json
K,O=sys.argv[1:]
CM=0.35278*50/10; BB=(600,70,1350,1060); s=0.5 # px per cm
out={}
for sh in ['ק-2','ק-3','ק-4']:
    p=pdfplumber.open(f'{K}/{sh}.pdf').pages[0]
    W=int((BB[2]-BB[0])*CM*s)+10;H=int((BB[3]-BB[1])*CM*s)+10
    img=np.zeros((H,W),np.uint8); tread=np.zeros((H,W),np.uint8)
    tp=lambda x,y:(int((x-BB[0])*CM*s)+5,int((y-BB[1])*CM*s)+5)
    for l in p.lines+p.curves+p.rects:
        lw=round(l.get('linewidth') or 0,2)
        pts=l.get('pts') or [(l['x0'],l['top']),(l['x1'],l['top']),(l['x1'],l['bottom']),(l['x0'],l['bottom']),(l['x0'],l['top'])]
        if not all(BB[0]<=x<=BB[2] and BB[1]<=y<=BB[3] for x,y in pts): continue
        if l.get('fill') and str(l.get('non_stroking_color')).startswith('(0.596'):
            cv2.fillPoly(img,[np.array([tp(x,y) for x,y in pts],np.int32)],255); continue
        if l.get('fill'): continue
        for a,b in zip(pts,pts[1:]):
            L=math.dist(a,b)
            if lw in (0.42,1.42,1.63) and L>=12: cv2.line(img,tp(*a),tp(*b),255,1)
            if lw==0.21 and L>=12: cv2.line(tread,tp(*a),tp(*b),255,1)
    k=cv2.getStructuringElement(cv2.MORPH_RECT,(25,25)) # 50cm
    cl=cv2.morphologyEx(img,cv2.MORPH_CLOSE,k)
    ff=cl.copy(); m=np.zeros((H+2,W+2),np.uint8); cv2.floodFill(ff,m,(0,0),128)
    inside=(ff!=128).astype(np.uint8)
    n,lab,st,_=cv2.connectedComponentsWithStats(inside); big=1+np.argmax(st[1:,cv2.CC_STAT_AREA]); mask=(lab==big)
    A=mask.sum()/(s*s)/1e4
    vis=cv2.cvtColor(img,cv2.COLOR_GRAY2BGR); vis[mask&(img==0)]=(210,235,255); vis[tread>0]=(0,140,255)
    cv2.imwrite(f'{O}/outline_{sh}.png',vis)
    ys,xs=np.where(mask)
    out[sh]=dict(outline_m2=round(A,1),w=round((xs.max()-xs.min())/s/100,2),h=round((ys.max()-ys.min())/s/100,2))
    print(sh,out[sh])
json.dump(out,open(f'{O}/outline.json','w'))
