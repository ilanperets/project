import re,sys,json
UNITS=r'(מ"ק|מ"ר|מ" ר|מ "ר|מ" ק|מ "ק|מ"א|מטר|מ\'|יח\'|קומפ\'|טון|ק"ג|קומפלט|ש"ע|ימי עבודה|יום|שעה|מ"ט)'
NUM=r'([\d,]+\.\d{2}|[\d,]+)'
def parse(fn):
    L=open(fn,encoding='utf-8').read().splitlines()
    items=[];cur=None;struct=None;chapter=None;sub=None
    for ln in L:
        s=ln.strip()
        if not s: continue
        m=re.search(r'מבנה\s+(\d{2})\s*(.*)$',s)
        if m and len(s)<60 and 'סה"כ' not in s: struct=m.group(1)+' '+m.group(2).strip()
        m=re.match(r'^פרק\s+(\d{2})\s*(.*)$',s)
        if m: chapter=m.group(1)+' '+m.group(2).strip()
        m=re.search(r'תת פרק\s+([\d.]+)\s*(.*)$',s)
        if m and 'סה"כ' not in s: sub=m.group(1)+' '+m.group(2).strip()
        mc=re.search(r'(\d{2}\.\d{1,3}\.\d{3,4})(?!\d)',s)
        nums=re.match(r'^'+NUM+r'\s+'+NUM+r'\s+'+NUM+r'\s+'+UNITS+r'\s*(.*)$',s)
        nums2=re.match(r'^'+NUM+r'\s+'+UNITS+r'\s*(.*)$',s)  # qty only (unpriced)
        if 'סה"כ' in s or 'להעברה' in s or 'מהעברה' in s: 
            continue
        if mc and not s.startswith(mc.group(1)) and not nums:
            # code inside description line
            pass
        if mc:
            cur=dict(code=mc.group(1),struct=struct,chapter=chapter,sub=sub,desc=s.replace(mc.group(1),'').strip(),unit=None,qty=None,price=None,total=None)
            items.append(cur)
        elif cur and not nums and not nums2 and cur['unit'] is None and not re.match(r'^(פרק|תת פרק|מבנה)',s):
            cur['desc']+=' '+s
        if nums and cur:
            tot,pr,q,u,rest=nums.groups()
            f=lambda x: float(x.replace(',',''))
            cur.update(total=f(tot),price=f(pr),qty=f(q),unit=u.replace(' ',''))
            if rest and not mc: cur['desc']+=' '+re.sub(r'\d{2}\.\d{1,3}\.\d{3,4}','',rest)
        elif nums2 and cur and cur['unit'] is None:
            q,u,rest=nums2.groups(); cur.update(qty=float(q.replace(',','')),unit=u.replace(' ',''))
    for it in items: it['desc']=re.sub(r'\s+',' ',it['desc']).strip()
    return items
if __name__=='__main__':
    its=parse(sys.argv[1]); json.dump(its,open(sys.argv[2],'w'),ensure_ascii=False,indent=0)
    import collections
    tot=collections.defaultdict(float)
    for i in its:
        if i['total']: tot[(i['struct'],i['chapter'])]+=i['total']
    for k,v in tot.items(): print(k, round(v,2))
    print('items',len(its),'priced',sum(1 for i in its if i['total']),'no-unit',sum(1 for i in its if not i['unit']))
