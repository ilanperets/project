from playwright.sync_api import sync_playwright
S='/tmp/claude-0/-home-claude/90f9075a-8e8a-5948-8a8e-80f1167be059/scratchpad'
with sync_playwright() as p:
    b=p.chromium.launch()
    for n,w,dark in [('desk',1200,False),('phone',400,False),('phone_dark',400,True)]:
        pg=b.new_page(viewport={'width':w,'height':900},color_scheme='dark' if dark else 'light')
        errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.goto('file:///home/claude/out/kamuyot_demo.html'); pg.wait_for_timeout(1200)
        print(n,pg.evaluate('[document.documentElement.scrollWidth,innerWidth]'),'errors',errs)
        pg.locator('#hofim').screenshot(path=f'{S}/hofim/shot_{n}.png')
    b.close()
