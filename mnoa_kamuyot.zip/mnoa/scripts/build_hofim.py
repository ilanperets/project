import json
S='/tmp/claude-0/-home-claude/90f9075a-8e8a-5948-8a8e-80f1167be059/scratchpad/hofim/'
B=json.load(open(S+"piles010.json"))+json.load(open(S+"piles110.json")); C=json.load(open(S+"pilesC110.json"))
boq={('B',50):310,('B',60):1900,('B',70):400,('C',60):1940,('C',70):65}
price={50:212,60:280,70:360}
rows=[];diff=0;tn=tr=0
for bld,P in (('B',B),('C',C)):
    for dia in sorted(set(p['dia'] for p in P)):
        n=sum(1 for p in P if p['dia']==dia); rd=sum(1 for p in P if p['dia']==dia and not p.get('est'))
        q=boq[(bld,dia)]; diff+=(q-n*12)*price[dia]; tn+=n; tr+=rd
        rows.append(f'<tr><th scope="row"><span class="item">מבנה {bld} · <bdi dir="ltr">Ø{dia}</bdi></span></th>'
          f'<td class="num eng" data-l="כלונסאות">{n}</td><td class="num" data-l="תגיות שנקראו">{rd}</td>'
          f'<td class="num" data-l="מ׳ לפי התוכנית">{n*12:,}</td><td class="num" data-l="מ׳ בכתב">{q:,}</td>'
          f'<td class="num" data-l="מ׳ לכלונס בכתב">{q/n:.1f}</td></tr>')
print("total",tn,"read",tr,"diff ₪",diff)
open(S+"pile_rows.html","w").write("\n".join(rows))
