import sys, json, numpy as np, collections
sys.path.insert(0,'/tmp/claude-0/-home-claude/90f9075a-8e8a-5948-8a8e-80f1167be059/scratchpad/scripts')
import pymupdf as fitz
from PIL import Image
from scipy import ndimage as ndi
import hofim_fp as FP, hofim_vert2 as V
O=FP.O; CM=2.0; z=75*0.03528/CM
def loadF(sh):
    shp=json.load(open(O+f'fp_{sh}.shape')); return np.unpackbits(np.load(O+f'fp_{sh}.npy'))[:shp[0]*shp[1]].reshape(shp).astype(bool)
def precast(sh,F):
    src=fitz.open(FP.BD%sh)[0]
    def p(d): return d['items'] if d['layer']=='S_LOHAD' else None
    _,pg=V.replay(src,p,width=1.0,fill=False); Lh=V.raster(pg,75,0)
    if Lh.sum()==0: return np.zeros_like(F)
    P=ndi.binary_closing(Lh,structure=np.ones((3,3)),iterations=35)
    P=ndi.binary_fill_holes(P)&F
    P=ndi.binary_opening(P,structure=np.ones((3,3)),iterations=4)
    return P
def run(sh):
    F=loadF(sh)
    marks=[m for m in json.load(open(O+f'marks_{sh}.json')) if m.get('D')]
    seeds=np.zeros(F.shape,np.int32)
    for i,m in enumerate(marks,1):
        x,y=int(m['m'][0]*z),int(m['m'][1]*z); seeds[min(y,F.shape[0]-1),min(x,F.shape[1]-1)]=i
    src=fitz.open(FP.BD%sh)[0]
    def pw(d): return d['items'] if d['layer'] in ('s_wall_DOWN','S_WALL_UP') else None
    _,pg=V.replay(src,pw,width=1.0,fill=False); Wl=V.raster(pg,75,0)
    Sm,Hl,_=V.masks(FP.BD%sh,75); Wb=ndi.binary_dilation(Wl|Sm|ndi.binary_closing(Hl,structure=np.ones((5,5))),iterations=2)
    comp,n=ndi.label(F&~Wb); void=np.zeros_like(F); voids=[]
    for c,sl in enumerate(ndi.find_objects(comp),1):
        cm=comp[sl]==c; a=cm.sum()*CM*CM/1e4
        if a>30 and (seeds[sl][cm]>0).sum()==0:
            void[sl]|=cm; voids.append(round(a,1))
    void=ndi.binary_dilation(void,iterations=3)&F
    F=F&~void
    print('  voids',sh,voids)
    d,idx=ndi.distance_transform_edt(seeds==0,return_indices=True)
    L=seeds[idx[0],idx[1]]; L[~F]=0
    far=(d*CM/100>12)&F
    P=precast(sh,F)
    area=collections.defaultdict(float)
    for i,m in enumerate(marks,1):
        cell=L==i
        for tag,mask in (('cast',cell&~P),('pre',cell&P)):
            a=mask.sum()*CM*CM/1e4
            if a==0: continue
            D=m['D']; key=f"{tag}_{D}"
            area[key]+=a
    return dict(area), far.sum()*CM*CM/1e4, P.sum()*CM*CM/1e4, L, P
if __name__=="__main__":
    allr={}
    for sh in sys.argv[1:]:
        r,far,pa,L,P=run(sh); allr[sh]=r
        print(sh,{k:round(v,1) for k,v in sorted(r.items())},"total",round(sum(r.values()),1),"far>12m",round(far,1),"precast",round(pa,1))
        np.save(O+f'slabL_{sh}.npy',L); np.save(O+f'slabP_{sh}.npy',np.packbits(P))
    json.dump(allr,open(O+'slab_areas.json','w'))
