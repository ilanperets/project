import pymupdf as fitz, json, re, sys, collections, math
pdf, ocrf, dpi = sys.argv[1], sys.argv[2], 250
SCALE=float(sys.argv[4] if len(sys.argv)>4 else 75)
SC=float(sys.argv[4] if len(sys.argv)>4 else 75)*0.03528
pg=fitz.open(pdf)[0]
circ=[]
for d in pg.get_drawings():
    if d['layer']!='S_Col_Down': continue
    r=d['rect']; k="".join(i[0] for i in d['items'])
    if k.count('c')>=4 and abs(r.width-r.height)<0.08*r.width and r.width>10:
        pts=[it[1] for it in d['items']]+[d['items'][-1][-1]]
        dmax=max(abs(p-q) for p in pts for q in pts)
        cx,cy=(r.x0+r.x1)/2,(r.y0+r.y1)/2; dia=round(dmax*SC/10)*10
        if not any(abs(cx-c[0])<2 and abs(cy-c[1])<2 for c in circ): circ.append((cx,cy,dia))
W=json.load(open(ocrf)); f=dpi/72
# merge tokens to find L values: token containing L( or Lm followed by number possibly in next token
Ls=[]
for i,w in enumerate(W):
    t=w[0]
    if re.match(r'^L',t) and ('m' in t or '(' in t):
        m=re.search(r'(\d{1,2}[.,]\d)',t)
        if not m and i+1<len(W): m=re.search(r'^(\d{1,2}[.,]\d)$',W[i+1][0])
        if m and float(m.group(1).replace(',','.'))>=4: Ls.append((float(m.group(1).replace(',','.')), (w[1]+w[3]/2)/f, (w[2]+w[4]/2)/f))
nos=[]
for i,w in enumerate(W):
    m=re.match(r'^No\.?(\d+)$',w[0]) or (re.match(r'^No\.?$',w[0]) and i+1<len(W) and re.match(r'^(\d+)$',W[i+1][0]))
    if m: nos.append(((w[1])/f,(w[2]+w[4]/2)/f))
print("circles",len(circ),collections.Counter(c[2] for c in circ),"L tokens",len(Ls),collections.Counter(l[0] for l in Ls),"No",len(nos))
# assign: each circle -> nearest L token whose position is below/right within 70pt, greedy by distance
pairs=sorted(((math.hypot(l[1]-c[0],l[2]-c[1]),ci,li) for ci,c in enumerate(circ) for li,l in enumerate(Ls)), key=lambda x:x[0])
ac={};al=set()
for dist,ci,li in pairs:
    if dist>75*75/SCALE: break
    if ci in ac or li in al: continue
    ac[ci]=li; al.add(li)
res=[]
for ci,c in enumerate(circ):
    res.append(dict(x=c[0],y=c[1],dia=c[2],L=Ls[ac[ci]][0] if ci in ac else None))
mode={}
for dia in set(c[2] for c in circ):
    v=[r['L'] for r in res if r['dia']==dia and r['L']]; mode[dia]=collections.Counter(v).most_common(1)[0][0] if v else None
summ=collections.defaultdict(lambda:[0,0,0.0])
for r in res:
    s=summ[r['dia']]; s[0]+=1
    if r['L'] is None: s[1]+=1; r['L']=mode[r['dia']]; r['est']=True
    s[2]+=r['L'] or 0
for k,v in sorted(summ.items()): print(f"Ø{k}: {v[0]} piles, {v[1]} L-estimated, total {v[2]:.1f} m", collections.Counter(r['L'] for r in res if r['dia']==k))
json.dump(res,open(sys.argv[3],'w'))
