import fitz,sys,json,numpy as np,cv2
from skimage.morphology import skeletonize
A,O=sys.argv[1:3]
CMs=0.35278*50/10
REG={'pl0':dict(file='347-01-pl0.pdf',k=1.627,ref=(1201.0,805.9),H=3.55),'pl1':dict(file='347-02-pl1.pdf',k=1.765,ref=(1072.2,976.2),H=3.35)}
ref_cm=(1119,1033)
m4=np.load(f'{O}/mask_ק-4.npy').astype(np.uint8)
cnt,_=cv2.findContours(m4,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE); c=max(cnt,key=cv2.contourArea)[:,0,:]
wing_cm=[((x-5)/0.5+590*CMs,(y-5)/0.5+40*CMs) for x,y in c]
px=2.0; res={}
for key,r in REG.items():
    d=fitz.open(f"{A}/{r['file']}"); dr=d[0].get_drawings()
    k=r['k']; to=lambda x,y:((x-r['ref'][0])*k+ref_cm[0],(y-r['ref'][1])*k+ref_cm[1])
    xs=[x for x,y in wing_cm]; ys=[y for x,y in wing_cm]
    X0,Y0=min(xs)-80,min(ys)-80; W=int((max(xs)-X0+80)/px); H=int((max(ys)-Y0+80)/px)
    T=lambda xc,yc:(int((xc-X0)/px),int((yc-Y0)/px))
    wing=np.zeros((H,W),np.uint8); cv2.fillPoly(wing,[np.array([T(x,y) for x,y in wing_cm],np.int32)],1)
    wingD=cv2.dilate(wing,np.ones((31,31),np.uint8))
    wl=np.zeros((H,W),np.uint8); conc=np.zeros((H,W),np.uint8)
    for x in dr:
        lay=x.get('layer')
        if x.get('fill') and x['fill'][0]<0.8 and abs(x['fill'][0]-x['fill'][2])<0.05 and x['fill'][0]>0.4:
            for it in x['items']:
                if it[0]=='re': r_=it[1]; cv2.rectangle(conc,T(*to(r_.x0,r_.y0)),T(*to(r_.x1,r_.y1)),1,-1)
            pts=[]
            for it in x['items']:
                if it[0]=='l': pts+= [it[1],it[2]]
                elif it[0]=='c': pts+=[it[1],it[4]]
            if len(pts)>=3: cv2.fillPoly(conc,[np.array([T(*to(p.x,p.y)) for p in pts],np.int32)],1)
            continue
        if lay!='IZ  wall-0.6': continue
        for it in x['items']:
            if it[0]=='l': cv2.line(wl,T(*to(it[1].x,it[1].y)),T(*to(it[2].x,it[2].y)),1,1)
            elif it[0]=='re':
                r_=it[1]; cv2.rectangle(wl,T(*to(r_.x0,r_.y0)),T(*to(r_.x1,r_.y1)),1,1)
            elif it[0]=='qu':
                q=it[1]; cv2.polylines(wl,[np.array([T(*to(p.x,p.y)) for p in (q.ul,q.ur,q.lr,q.ll)],np.int32)],True,1,1)
            elif it[0]=='c': cv2.line(wl,T(*to(it[1].x,it[1].y)),T(*to(it[4].x,it[4].y)),1,1)
    wl&=wingD; conc&=wingD
    solid=cv2.morphologyEx(wl|conc,cv2.MORPH_CLOSE,cv2.getStructuringElement(cv2.MORPH_RECT,(17,17)))  # 34cm
    blocks=(solid==1)&(conc==0)
    blocks=cv2.morphologyEx(blocks.astype(np.uint8),cv2.MORPH_OPEN,np.ones((3,3),np.uint8)).astype(bool)
    dist=cv2.distanceTransform(blocks.astype(np.uint8),cv2.DIST_L2,5); sk=skeletonize(blocks)
    t=2*dist[sk]*px
    outside=(1-wing).astype(np.uint8)
    near=cv2.dilate(outside,np.ones((19,19),np.uint8))[sk]==1   # within ~18cm of outline
    L={'חוץ':0,'פנים 10':0,'פנים 20':0,'דק<7':0}
    for ti,ex in zip(t,near):
        if ti<7: L['דק<7']+=px
        elif ex: L['חוץ']+=px
        elif ti<17: L['פנים 10']+=px
        else: L['פנים 20']+=px
    res[key]={k2:round(v/100,1) for k2,v in L.items()}; res[key]['H']=r['H']
    vis=np.full((H,W,3),255,np.uint8); vis[conc==1]=(150,150,150)
    sk_img=np.zeros((H,W,3),np.uint8)
    ys_,xs_=np.where(sk)
    for yy,xx,ti,ex in zip(ys_,xs_,t,near):
        col=(0,0,0) if ti<7 else ((200,60,0) if ex else ((0,140,255) if ti<17 else (0,0,220)))
        cv2.circle(vis,(xx,yy),2,col,-1)
    cv2.polylines(vis,[np.array([T(x,y) for x,y in wing_cm],np.int32)],True,(0,170,0),1)
    cv2.imwrite(f'{O}/walls_{key}.png',vis)
    print(key,res[key])
json.dump(res,open(f'{O}/walls_layers.json','w'),ensure_ascii=False)
