import { Dwg_File_Type, LibreDwg } from '@mlightcad/libredwg-web';
import fs from 'fs';
const [,, file, out] = process.argv;
const lib = await LibreDwg.create(process.cwd()+'/node_modules/@mlightcad/libredwg-web/wasm/');
const buf = fs.readFileSync(file);
const dwg = lib.dwg_read_data(buf, Dwg_File_Type.DWG);
const db = lib.convert(dwg);
const ents = db.entities || [];
const byType={}, byLayer={};
for (const e of ents){ byType[e.type]=(byType[e.type]||0)+1; byLayer[e.layer]=(byLayer[e.layer]||0)+1; }
console.log('entities', ents.length);
console.log('types', JSON.stringify(byType));
console.log('layers in tables', (db.tables?.LAYER?.entries||[]).length);
console.log('layers used', JSON.stringify(Object.entries(byLayer).sort((a,b)=>b[1]-a[1]).slice(0,80)));
console.log('blocks', (db.tables?.BLOCK_RECORD?.entries||[]).length);
console.log('keys', Object.keys(db));
fs.writeFileSync(out, JSON.stringify(db, (k,v)=> typeof v==='bigint'? Number(v): v));
