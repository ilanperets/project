import fitz,sys,json,numpy as np,cv2
S='/tmp/claude-0/-home-claude/90f9075a-8e8a-5948-8a8e-80f1167be059/scratchpad'
A=S+"/corpus/hadera/T0620_olga_kg_b/אדריכלות_x/אדריכלות"; O=S+'/olga'
CMs=0.35278*50/10
REG={'pl0':dict(file='347-01-pl0.pdf',k=1.627,ref=(1201.0,805.9),H=3.55),'pl1':dict(file='347-02-pl1.pdf',k=1.765,ref=(1072.2,976.2),H=3.35)}
ref_cm=(1119,1033)
m4=np.load(f'{O}/mask_ק-4.npy').astype(np.uint8)
cnt,_=cv2.findContours(m4,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE); c=max(cnt,key=cv2.contourArea)[:,0,:]
wing_cm=[((x-5)/0.5+590*CMs,(y-5)/0.5+40*CMs) for x,y in c]
px=2.0; out={}
def draw(dr,keep,T,to,img,th=1):
    for x in dr:
        if not keep(x): continue
        for it in x['items']:
            if it[0]=='l': cv2.line(img,T(*to(it[1].x,it[1].y)),T(*to(it[2].x,it[2].y)),1,th)
            elif it[0]=='re': r_=it[1]; cv2.rectangle(img,T(*to(r_.x0,r_.y0)),T(*to(r_.x1,r_.y1)),1,th)
            elif it[0]=='qu': q=it[1]; cv2.polylines(img,[np.array([T(*to(p.x,p.y)) for p in (q.ul,q.ur,q.lr,q.ll)],np.int32)],True,1,th)
            elif it[0]=='c': cv2.line(img,T(*to(it[1].x,it[1].y)),T(*to(it[4].x,it[4].y)),1,th)
for key,r in REG.items():
    d=fitz.open(f"{A}/{r['file']}"); dr=d[0].get_drawings()
    k=r['k']; to=lambda x,y,r=r,k=k:((x-r['ref'][0])*k+ref_cm[0],(y-r['ref'][1])*k+ref_cm[1])
    xs=[x for x,y in wing_cm]; ys=[y for x,y in wing_cm]
    X0,Y0=min(xs)-80,min(ys)-80; W=int((max(xs)-X0+80)/px); H=int((max(ys)-Y0+80)/px)
    T=lambda xc,yc,X0=X0,Y0=Y0:(int((xc-X0)/px),int((yc-Y0)/px))
    wing=np.zeros((H,W),np.uint8); cv2.fillPoly(wing,[np.array([T(x,y) for x,y in wing_cm],np.int32)],1)
    wl=np.zeros((H,W),np.uint8); win=np.zeros((H,W),np.uint8); san=np.zeros((H,W),np.uint8); conc=np.zeros((H,W),np.uint8)
    draw(dr,lambda x:x.get('layer')=='IZ  wall-0.6',T,to,wl,2)
    draw(dr,lambda x:x.get('layer') in('IZ  win','IZ  win-0.3'),T,to,win,2)
    draw(dr,lambda x:x.get('layer')=='IZ  san',T,to,san,2)
    for x in dr:
        if x.get('fill') and x['fill'][0]<0.8 and abs(x['fill'][0]-x['fill'][2])<0.05 and x['fill'][0]>0.4:
            pts=[]
            for it in x['items']:
                if it[0]=='l': pts+=[it[1],it[2]]
                elif it[0]=='c': pts+=[it[1],it[4]]
                elif it[0]=='re': rr=it[1]; pts+=[rr.tl,rr.tr,rr.br,rr.bl]
            if len(pts)>=3: cv2.fillPoly(conc,[np.array([T(*to(p.x,p.y)) for p in pts],np.int32)],1)
    solid=cv2.morphologyEx(wl|conc|win,cv2.MORPH_CLOSE,cv2.getStructuringElement(cv2.MORPH_RECT,(17,17)))
    # building outline as wall too
    edge=cv2.morphologyEx(wing,cv2.MORPH_GRADIENT,np.ones((5,5),np.uint8))
    barrier=solid|edge
    closed=cv2.morphologyEx(barrier,cv2.MORPH_CLOSE,cv2.getStructuringElement(cv2.MORPH_RECT,(55,55)))  # bridge door gaps up to ~110cm
    free=((wing==1)&(closed==0)).astype(np.uint8)
    n,lab,st,cen=cv2.connectedComponentsWithStats(free,8)
    rooms=[]
    vis=np.full((H,W,3),255,np.uint8); vis[barrier==1]=(60,60,60)
    rng=np.random.default_rng(3)
    for i in range(1,n):
        a=st[i,cv2.CC_STAT_AREA]*px*px/1e4
        if a<1.2: continue
        m=(lab==i).astype(np.uint8)
        cs,_=cv2.findContours(m,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
        per=sum(cv2.arcLength(cc,True) for cc in cs)*px/100
        # grow region back to wall faces: area & perimeter of free space ignoring the 110cm bridging
        wet=int((san*cv2.dilate(m,np.ones((9,9),np.uint8))).sum()>20)
        rooms.append(dict(area=round(a,2),per=round(per,2),wet=wet,cx=int(cen[i][0]),cy=int(cen[i][1])))
        col=(80,170,240) if not wet else (60,200,120)
        vis[m==1]=col
    vis[san==1]=(0,90,0)
    cv2.imwrite(f'{O}/rooms_{key}.png',vis)
    fr=((wing==1)&(solid==0)).astype(np.uint8)
    fr=cv2.morphologyEx(fr,cv2.MORPH_OPEN,np.ones((5,5),np.uint8))
    cs,_=cv2.findContours(fr,cv2.RETR_CCOMP,cv2.CHAIN_APPROX_SIMPLE)
    face=sum(cv2.arcLength(cv2.approxPolyDP(cc,2,True),True) for cc in cs if cv2.contourArea(cc)*px*px/1e4>0.3)*px/100
    # wet rooms: free-space components (unbridged) touching a wet bridged room
    wetmask=np.zeros_like(fr)
    for rm in rooms:
        if rm['wet'] and rm['area']<12: 
            l=lab[rm['cy'],rm['cx']]
            if l>0: wetmask|=(lab==l).astype(np.uint8)
    wetgrow=cv2.dilate(wetmask,np.ones((29,29),np.uint8))&fr
    cw,_=cv2.findContours(wetgrow,cv2.RETR_CCOMP,cv2.CHAIN_APPROX_SIMPLE)
    wetper=sum(cv2.arcLength(cv2.approxPolyDP(cc,2,True),True) for cc in cw if cv2.contourArea(cc)*px*px/1e4>0.3)*px/100
    wing_per=sum(cv2.arcLength(cc,True) for cc in cv2.findContours(wing,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)[0])*px/100
    out[key]=dict(rooms=rooms,H=r['H'],free_total=round(float(fr.sum()*px*px/1e4),1),face=round(face,1),wet_area=round(float(wetgrow.sum()*px*px/1e4),1),wet_per=round(wetper,1),wing_per=round(wing_per,1))
    v2=np.full((H,W,3),255,np.uint8); v2[solid==1]=(150,150,150); v2[wetgrow==1]=(200,240,200)
    for cc in cs:
        if cv2.contourArea(cc)*px*px/1e4>0.3: cv2.drawContours(v2,[cv2.approxPolyDP(cc,2,True)],-1,(0,0,255),2)
    cv2.imwrite(f'{O}/faces_{key}.png',v2)
    print(key,out[key]['free_total'],'face',out[key]['face'],'wet',out[key]['wet_area'],out[key]['wet_per'],'wing per',out[key]['wing_per'])
    print(key,'rooms',len(rooms),'area',round(sum(x['area'] for x in rooms),1),'per',round(sum(x['per'] for x in rooms),1),'wet',[ (x['area'],x['per']) for x in rooms if x['wet']], 'free',out[key]['free_total'])
json.dump(out,open(f'{O}/rooms.json','w'))
