import pymupdf as fitz, sys, numpy as np, collections
from PIL import Image, ImageDraw
def fill_mask(pdf, layers, fills=None, dpi_cm=2.0, scale=75, src_types=('f','fs')):
    pg=fitz.open(pdf)[0]; cmpt=scale*0.03528   # cm per pt
    k=cmpt/dpi_cm   # px per pt  -> 1px = dpi_cm cm
    k=1/ (dpi_cm/cmpt)
    W,H=int(pg.rect.width*k)+1,int(pg.rect.height*k)+1
    im=Image.new("L",(W,H),0); dr=ImageDraw.Draw(im)
    n=0
    for d in pg.get_drawings():
        if d['layer'] not in layers or d['type'] not in src_types: continue
        if fills and tuple(round(c,2) for c in (d.get('fill') or ())) not in fills: continue
        for it in d['items']:
            if it[0]=='re': r=it[1]; dr.rectangle([r.x0*k,r.y0*k,r.x1*k,r.y1*k],fill=255)
            elif it[0]=='qu': q=it[1]; dr.polygon([(p.x*k,p.y*k) for p in (q.ul,q.ur,q.lr,q.ll)],fill=255)
        # polygon from l/c items
        pts=[]
        for it in d['items']:
            if it[0]=='l': pts+= [it[1],it[2]]
            elif it[0]=='c': pts+= [it[1],it[4]]
        if len(pts)>=3: dr.polygon([(p.x*k,p.y*k) for p in pts],fill=255)
        n+=1
    return np.array(im)>0, n
if __name__=="__main__":
    m,n=fill_mask(sys.argv[1], sys.argv[2].split(','), fills={(0.5,0.5,0.5)} if sys.argv[3]=='g' else None, scale=float(sys.argv[4]))
    print(n, "area m2", m.sum()*4/1e4)
    Image.fromarray((~m*255).astype('uint8')).save(sys.argv[5])
