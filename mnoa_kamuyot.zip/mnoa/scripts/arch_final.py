import json
a=json.load(open('olga/arch/arch.json'))
gross=187.3; stair=12.5; elev=3.34
conc={'pl0':9.42,'pl1':9.13}
ext_len=12.1+15.52+12.1   # top, right, bottom (left side adjoins existing phase A)
out={}
for k in ('pl0','pl1'):
    w=a[k]['wall_len_m']
    blocks=ext_len*0.25 + w['פנים ~10']*0.13 + w['פנים ~20']*0.23
    out[k]=dict(net_floor=round(gross-conc[k]-blocks-stair-elev,1),engine_free=a[k]['floor_net_m2'],int10=w['פנים ~10'],int20=w['פנים ~20'])
H={'pl0':3.55,'pl1':3.35}
int10_m2=sum(out[k]['int10']*H[k] for k in out); int20_m2=sum(out[k]['int20']*H[k] for k in out)
res=dict(floors=out,floor_total=round(sum(v['net_floor'] for v in out.values()),1),
         blocks10_gross=round(int10_m2,1),blocks20_gross=round(int20_m2,1),ext_len=ext_len)
print(json.dumps(res,ensure_ascii=False,indent=1))
json.dump(res,open('olga/arch_final.json','w'),ensure_ascii=False)
