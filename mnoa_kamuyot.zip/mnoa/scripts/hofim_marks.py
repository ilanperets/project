import sys, math, json, re, numpy as np
sys.path.insert(0,'/tmp/claude-0/-home-claude/90f9075a-8e8a-5948-8a8e-80f1167be059/scratchpad/scripts')
import pymupdf as fitz, pytesseract
from PIL import Image
from layer_render import replay
import hofim_slab as HS
O=HS.O
def read(sh):
    src=fitz.open(HS.BD%sh)[0]
    ms=HS.markers(src); dg=HS.diagonals(src)
    _,tp=replay(HS.BD%sh,['S_TEXT2','S_TEXT1','TXT'])
    out=[]
    for m in ms:
        angs=[0]
        best=None
        for a,b in dg:
            v=b-a; w=fitz.Point(m)-a; t=max(0,min(1,(w.x*v.x+w.y*v.y)/(v.x**2+v.y**2))); q=a+v*t
            dd=math.hypot(q.x-m[0],q.y-m[1])
            if best is None or dd<best[0]: best=(dd,math.degrees(math.atan2(v.y,v.x)))
        if best and best[0]<8: angs=[best[1],best[1]+180,0]
        else: angs=[0,90,-90]
        clip=fitz.Rect(m[0]-60,m[1]-60,m[0]+60,m[1]+60)
        pix=tp.get_pixmap(clip=clip,dpi=300,colorspace=fitz.csGRAY)
        base=Image.frombytes("L",[pix.width,pix.height],pix.samples)
        got=None
        for a in angs:
            im=base.rotate(a,expand=True,fillcolor=255)
            t=pytesseract.image_to_string(im,config='--psm 11')
            t2=t.replace('\n',' ')
            md=re.search(r'D\s*[=:]\s*(\d{2})(?:\s*\+\s*(\d{1,2}))?',t2)
            mo=re.search(r'K\.?\s*[=:,.]*\s*([+\-—–])?\s*(\d{1,2})[.,](\d{2})',t2)
            if md:
                d=int(md.group(1)); top=int(md.group(2)) if md.group(2) else 0
                ok=None
                if mo: ok=(-1 if mo.group(1) and mo.group(1)!='+' else 1)*float(mo.group(2)+'.'+mo.group(3))
                got=dict(D=d,top=top,ok=ok,ang=a,txt=t2[:60]); break
        out.append(dict(m=m,**(got or {'D':None})))
    return out
if __name__=="__main__":
    for sh in sys.argv[1:]:
        r=read(sh); json.dump(r,open(O+f'marks_{sh}.json','w'))
        import collections
        print(sh,len(r),"readD",sum(1 for x in r if x['D']),collections.Counter((x['D'],x.get('top')) for x in r))
