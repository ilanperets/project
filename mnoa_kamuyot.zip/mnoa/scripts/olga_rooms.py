import sys, json, numpy as np, pymupdf as fitz
sys.path.insert(0,'/tmp/claude-0/-home-claude/90f9075a-8e8a-5948-8a8e-80f1167be059/scratchpad/scripts')
import hofim_vert2 as V
from scipy import ndimage as ndi
from PIL import Image
S='/tmp/claude-0/-home-claude/90f9075a-8e8a-5948-8a8e-80f1167be059/scratchpad'
A=S+"/corpus/hadera/T0620_olga_kg_b/אדריכלות_x/אדריכלות/347-06-tikra-ritspa.pdf"
CMPT=60/34.08   # cm per pt, from 60x60 acoustic grid
CM=2.0; z=CMPT/CM
def ras(src, pred, fill=False, width=1.2):
    _,pg=V.replay(src,pred,width=width,fill=fill)
    pix=pg.get_pixmap(matrix=fitz.Matrix(z,z),colorspace=fitz.csGRAY,alpha=False)
    return np.frombuffer(pix.samples,np.uint8).reshape(pix.height,pix.width)<128
if __name__=="__main__":
    src=fitz.open(A)[0]
    WL=('347-plans1|IZ  wall-0.6','IZ  wall-0.6','A-WALL-DETL')
    walls=ras(src,lambda d: d['items'] if d['layer'] in WL else None,width=1.5)
    wins=ras(src,lambda d: d['items'] if d['layer'] in ('347-plans1|IZ  win','347-plans1|IZ  win-0.3','IZ  win') else None,width=1.5)
    san=ras(src,lambda d: d['items'] if d['layer']=='347-plans1|IZ  san' else None,width=1.0)
    ceil_lines=ras(src,lambda d: [it for it in d['items'] if it[0]=='l' and abs(it[2]-it[1])>20] if d['layer']=='ceiling' else None,width=1.0)
    ceil_dots=ras(src,lambda d: [it for it in d['items'] if it[0]=='l' and abs(it[2]-it[1])<0.5] if d['layer']=='ceiling' else None,width=1.2)
    B=walls|wins
    np.save(S+'/olga/f_walls.npy',np.packbits(B)); np.save(S+'/olga/f_san.npy',np.packbits(san))
    np.save(S+'/olga/f_cl.npy',np.packbits(ceil_lines)); np.save(S+'/olga/f_cd.npy',np.packbits(ceil_dots))
    json.dump(list(B.shape),open(S+'/olga/f_shape.json','w'))
    rgb=np.full(B.shape+(3,),255,np.uint8); rgb[ceil_dots]=(200,200,240); rgb[ceil_lines]=(120,120,255); rgb[B]=(0,0,0); rgb[san]=(0,160,0)
    im=Image.fromarray(rgb); im.thumbnail((1400,1400)); im.save(S+'/olga/f_view.png'); print(B.shape)
