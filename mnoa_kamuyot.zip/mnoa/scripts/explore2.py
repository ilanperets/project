import json,sys,collections
db=json.load(open(sys.argv[1])); E=db['entities']
def first(pred): return next((e for e in E if pred(e)),None)
rt=first(lambda e:e['type']=='INSERT' and 'Room Tag' in (e.get('name') or ''))
print('roomtag', {k:rt[k] for k in ['insertionPoint','xScale','rotation','attribs']})
d=first(lambda e:e['type']=='INSERT' and e['layer']=='A-DOOR'); print('door',{k:d[k] for k in ['name','insertionPoint','xScale','yScale','rotation','attribs']})
print('all door blocks', collections.Counter(e['name'] for e in E if e['type']=='INSERT' and e['layer']=='A-DOOR'))
h=[e for e in E if e['type']=='HATCH']
print('hatch layers/patterns', collections.Counter((e['layer'],e['patternName'],e['solidFill']) for e in h).most_common(20))
hh=first(lambda e:e['type']=='HATCH' and e['layer']=='A-WALL-PATT'); print(json.dumps(hh['boundaryPaths'])[:800])
vp=[e for e in E if e['type']=='VIEWPORT']; print('VP', [{k:v.get(k) for k in ['center','width','height','viewCenter','viewHeight','ownerBlockRecordSoftId']} for v in vp])
print('owners', collections.Counter(e['ownerBlockRecordSoftId'] for e in E))
br=db['tables']['BLOCK_RECORD']['entries']; print([ (b.get('name'),b.get('handle')) for b in br[:6]])
print('layer table', [(l['name'],l.get('off'),l.get('frozen')) for l in db['tables']['LAYER']['entries']])
