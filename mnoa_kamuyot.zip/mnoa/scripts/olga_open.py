import pdfplumber,sys,math
from shapely.geometry import LineString,Polygon,box
from shapely.ops import unary_union,polygonize
K=sys.argv[1]; CM=0.35278*50/10; BB=(590,40,1360,1060)
def segs(sh,lwset,fillgray=False):
    p=pdfplumber.open(f'{K}/{sh}.pdf').pages[0]; out=[]
    for l in p.lines+p.curves+p.rects:
        lw=round(l.get('linewidth') or 0,2)
        pts=l.get('pts') or [(l['x0'],l['top']),(l['x1'],l['top']),(l['x1'],l['bottom']),(l['x0'],l['bottom']),(l['x0'],l['top'])]
        if not all(BB[0]<=x<=BB[2] and BB[1]<=y<=BB[3] for x,y in pts): continue
        if lw in lwset and not l.get('fill'):
            for a,b in zip(pts,pts[1:]):
                if math.dist(a,b)>0.5: out.append(((a[0]*CM,a[1]*CM),(b[0]*CM,b[1]*CM)))
    return out
for sh in ['ק-3','ק-4']:
    faces=[f for f in polygonize(unary_union([LineString(s) for s in segs(sh,{1.42})]))]
    walls=[f for f in faces if 2*f.area/f.length<50]
    print('==',sh)
    for f in sorted(walls,key=lambda f:-f.area):
        mb=f.minimum_rotated_rectangle; hole=mb.area-f.area
        print(f'  part {f.area/1e4:.3f} m2  bbox {[round(v) for v in f.bounds]}  bbox-area {mb.area/1e4:.2f}  enclosed {hole/1e4:.2f}')
    # stair treads: thin 0.21 lines, cluster in lower right
    tr=[s for s in segs(sh,{0.21})]
    xs=[v for a,b in tr for v in (a[0],b[0])]; ys=[v for a,b in tr for v in (a[1],b[1])]
    import collections
    # grid histogram to find the dense tread cluster
    cells=collections.Counter((int((a[0]+b[0])/2//100),int((a[1]+b[1])/2//100)) for a,b in tr)
    print('  0.21 lines',len(tr),'dense cells',cells.most_common(8))
