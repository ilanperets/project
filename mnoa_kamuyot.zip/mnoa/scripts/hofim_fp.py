import sys, json, numpy as np
sys.path.insert(0,'/tmp/claude-0/-home-claude/90f9075a-8e8a-5948-8a8e-80f1167be059/scratchpad/scripts')
import pymupdf as fitz
from PIL import Image
from scipy import ndimage as ndi
import hofim_vert2 as V
BD="/tmp/claude-0/-home-claude/90f9075a-8e8a-5948-8a8e-80f1167be059/scratchpad/corpus/hadera/T1222_hofim_highschool/קונסטרוקציה מבנה B_x/קונסטלציה מבנה B/מבנה B/CONST_B_%s.pdf"
O="/tmp/claude-0/-home-claude/90f9075a-8e8a-5948-8a8e-80f1167be059/scratchpad/hofim/"
V.CM=CM=2.0
LAY=('s_beam','s_wall_DOWN','S_WALL_UP','S_Col_Up','S_Col_Down','S-BEAM','1-BEAM','S_LOHAD')
def fp(sh, close=15):
    src=fitz.open(BD%sh)[0]
    def p(d): return d['items'] if d['layer'] in LAY else None
    _,pg=V.replay(src,p,width=1.0,fill=False); Bd=V.raster(pg,75,0)
    S,Hl,_=V.masks(BD%sh,75)
    Hm=ndi.binary_closing(Hl,structure=np.ones((5,5)))
    B=Bd|S|Hm
    cut=int(290*75*0.03528/CM); B[:,:cut]=False
    C=ndi.binary_closing(B,structure=np.ones((3,3)),iterations=close)
    F=ndi.binary_fill_holes(C)
    F=ndi.binary_opening(F,structure=np.ones((3,3)),iterations=5)
    lab,n=ndi.label(F); sz=ndi.sum(F,lab,range(1,n+1))
    keep=np.isin(lab,[i+1 for i,s in enumerate(sz) if s*CM*CM/1e4>20])
    return keep,B
if __name__=="__main__":
    for sh in sys.argv[1:]:
        F,B=fp(sh)
        print(sh,"footprint m2",round(F.sum()*CM*CM/1e4,1))
        rgb=np.full(F.shape+(3,),255,np.uint8); rgb[F]=(200,225,250); rgb[B]=(0,0,0)
        im=Image.fromarray(rgb); im.thumbnail((1400,1400)); im.save(O+f'fp_{sh}.png')
        np.save(O+f'fp_{sh}.npy',np.packbits(F)); json.dump(list(F.shape),open(O+f'fp_{sh}.shape','w'))
