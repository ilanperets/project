import pickle, glob, collections, json
O='/tmp/claude-0/-home-claude/90f9075a-8e8a-5948-8a8e-80f1167be059/scratchpad/hofim/'
W=lambda d:0.00617*d*d
def dedupe(r):
    best=collections.Counter()
    for rot,(fu,cn,sp) in r['passes'].items():
        c=collections.Counter((n,d,s,L) for n,d,s,L,_ in fu)
        for k,v in c.items(): best[k]=max(best[k],v)
    cc=collections.Counter()
    for rot,(fu,cn,sp) in r['passes'].items():
        c=collections.Counter((n,d,L) for n,d,L,_ in cn)
        for k,v in c.items(): cc[k]=max(cc[k],v)
    return best,cc
out={}
for f in sorted(glob.glob(O+'fb_*.pkl')):
    R=pickle.load(open(f,'rb'))
    for sh,r in R.items():
        if 'passes' not in r: continue
        b,c=dedupe(r)
        kg=sum(v*n*L/100*W(d) for (n,d,s,L),v in b.items())+sum(v*n*L/100*W(d) for (n,d,L),v in c.items())
        nlab=sum(b.values())+sum(c.values())
        marks=r.get('marks') or nlab
        cov=min(1.0,nlab/marks) if marks else 0
        out[sh]=dict(kg=kg,labels=nlab,marks=marks,cov=cov,est=kg/cov if cov>0 else 0)
tot=0
for sh,v in sorted(out.items()):
    print(sh,f"read {v['labels']}/{v['marks']} ({v['cov']:.0%})  kg {v['kg']:,.0f}  est {v['est']:,.0f}")
    tot+=v['est']
print('total est',round(tot))
json.dump(out,open(O+'slab_rebar.json','w'))
