import pdfplumber,sys,json,numpy as np,cv2
from skimage.morphology import skeletonize
A,O=sys.argv[1:3]
CMs=0.35278*50/10
# registration: struct cm <-> arch pt via elevator x0,y0 and per-sheet scale k
REG={'pl0':dict(file='347-01-pl0.pdf',k=1.627,ref_pt=(1201.0,805.9)),'pl1':dict(file='347-02-pl1.pdf',k=1.765,ref_pt=(1072.2,976.2))}
ref_cm=(1119,1033)
# wing polygon from roof mask (struct ק-4 slab outline), slab3 BB x0=590,y0=40, s=0.5
m4=np.load(f'{O}/../mask_ק-4.npy').astype(np.uint8)
cnt,_=cv2.findContours(m4,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE); c=max(cnt,key=cv2.contourArea)[:,0,:]
wing_cm=[((x-5)/0.5+590*CMs,(y-5)/0.5+40*CMs) for x,y in c]
res={}
px=2.0 # cm per pixel
for key,r in REG.items():
    p=pdfplumber.open(f"{A}/{r['file']}").pages[0]
    k=r['k']; to_cm=lambda x,y:((x-r['ref_pt'][0])*k+ref_cm[0],(y-r['ref_pt'][1])*k+ref_cm[1])
    xs=[x for x,y in wing_cm]; ys=[y for x,y in wing_cm]
    X0,Y0=min(xs)-60,min(ys)-60; W=int((max(xs)-X0+60)/px); H=int((max(ys)-Y0+60)/px)
    T=lambda xc,yc:(int((xc-X0)/px),int((yc-Y0)/px))
    wing=np.zeros((H,W),np.uint8); cv2.fillPoly(wing,[np.array([T(x,y) for x,y in wing_cm],np.int32)],1)
    lines=np.zeros((H,W),np.uint8); conc=np.zeros((H,W),np.uint8)
    for o in p.lines+p.curves+p.rects:
        pts=o.get('pts') or [(o['x0'],o['top']),(o['x1'],o['top']),(o['x1'],o['bottom']),(o['x0'],o['bottom']),(o['x0'],o['top'])]
        P=np.array([T(*to_cm(x,y)) for x,y in pts],np.int32)
        if (P[:,0]<0).all() or (P[:,0]>=W).all() or (P[:,1]<0).all() or (P[:,1]>=H).all(): continue
        if o.get('fill'):
            if '0.65' in str(o.get('non_stroking_color')): cv2.fillPoly(conc,[P],1)
            continue
        lw=round(o.get('linewidth') or 0,2)
        sc=str(o.get('stroking_color'))
        if lw>=0.84 or (lw==0.72 and sc.startswith('(0.0')): cv2.polylines(lines,[P],False,1,1)
    wingD=cv2.dilate(wing,np.ones((21,21),np.uint8))   # include exterior wall thickness (~40cm)
    lines&=wingD; conc&=wingD
    solid=cv2.morphologyEx(lines|conc,cv2.MORPH_CLOSE,cv2.getStructuringElement(cv2.MORPH_RECT,(15,15)))  # 30cm: fills wall strips
    # rooms: free space inside wing, with door gaps closed (1.1m)
    barrier=cv2.morphologyEx(solid,cv2.MORPH_CLOSE,cv2.getStructuringElement(cv2.MORPH_RECT,(55,55)))
    free=((barrier==0)&(wing==1)).astype(np.uint8)
    n,lab,st,_=cv2.connectedComponentsWithStats(free)
    rooms=[(i,st[i,cv2.CC_STAT_AREA]*px*px/1e4) for i in range(1,n) if st[i,cv2.CC_STAT_AREA]*px*px/1e4>=1.0]
    floor=((solid==0)&(wing==1)).sum()*px*px/1e4     # net floor (not barrier-closed)
    walls=((solid==1)&(wingD==1)&(conc==0))
    # wall thickness via distance transform on skeleton
    dist=cv2.distanceTransform(walls.astype(np.uint8),cv2.DIST_L2,5)
    sk=skeletonize(walls)
    t=(2*dist[sk]*px); L=px
    near_edge=cv2.dilate((1-wing).astype(np.uint8),np.ones((13,13),np.uint8))[sk]==1  # within ~12cm of outline -> exterior
    bins={'חוץ (פומיס 22)':0,'פנים ~10':0,'פנים ~20':0}
    for ti,ext in zip(t,near_edge):
        if ti<6: continue
        if ext and ti>=16: bins['חוץ (פומיס 22)']+=L
        elif ti<16: bins['פנים ~10']+=L
        else: bins['פנים ~20']+=L
    res[key]=dict(wing_m2=round(wing.sum()*px*px/1e4,1),floor_net_m2=round(floor,1),rooms=[round(a,1) for _,a in sorted(rooms,key=lambda z:-z[1])],
                  wall_len_m={k2:round(v/100,1) for k2,v in bins.items()},conc_m2=round(conc.sum()*px*px/1e4,2))
    vis=np.full((H,W,3),255,np.uint8); vis[free==1]=(235,215,190); vis[walls]=(60,60,200); vis[conc==1]=(120,120,120); vis[lines==1]=(0,0,0)
    cv2.polylines(vis,[np.array([T(x,y) for x,y in wing_cm],np.int32)],True,(0,160,0),2)
    cv2.imwrite(f'{O}/rooms_{key}.png',vis)
    print(key,json.dumps(res[key],ensure_ascii=False))
json.dump(res,open(f'{O}/arch.json','w'),ensure_ascii=False)
