import sys, pickle, json, re, numpy as np, collections
sys.path.insert(0,'/tmp/claude-0/-home-claude/90f9075a-8e8a-5948-8a8e-80f1167be059/scratchpad/scripts')
import glyphs as G
O='/tmp/claude-0/-home-claude/90f9075a-8e8a-5948-8a8e-80f1167be059/scratchpad/hofim/'
BD="/tmp/claude-0/-home-claude/90f9075a-8e8a-5948-8a8e-80f1167be059/scratchpad/corpus/hadera/T1222_hofim_highschool/קונסטרוקציה מבנה B_x/קונסטלציה מבנה B/מבנה B/CONST_B_%s.pdf"
P,_=pickle.load(open(O+'cl250.pkl','rb')); L=json.load(open(O+'labels250_id.json'))
def f2(m):
    v=G.nfeat(m); return v[:-1]
PV={int(k):f2(P[int(k)]['ex']) for k in L}
def classify(cs,thr):
    for c in cs:
        if c['kind']=='dot': c['t']='.'; continue
        h=c['y1']-c['y0']; w=c['x1']-c['x0']
        if h>c['H']*1.25 and w>c['H']*1.25: c['t']='#'; continue
        v=f2(c['m']); best=min(((np.abs(pv-v).sum(),k) for k,pv in PV.items()))
        c['t']=L[str(best[1])] if best[0]<thr else '?'
FIX={'Z':'5','ß':'3'}
W=lambda d:0.00617*d*d
SL=re.compile(r'(\d{1,3})\s*Φ\s*w?\s*(\d{1,2})\s*@\s*(\d{1,2})\s*L\s*=\s*(\d{2,4})')
CNT=re.compile(r'(\d{1,2})\s*Φ\s*w?\s*(\d{1,2})\s*L\s*=\s*(\d{2,4})')
SP=re.compile(r'Φ\s*w?\s*(\d{1,2})\s*@\s*(\d{1,2})\s*L\s*=\s*(\d{2,4})')
def run(sh, layers, H, thr=20, dpi=300):
    a=G.render(BD%sh,layers,dpi=dpi)
    cs,_=G.comps(a,hmin=int(H*0.4),hmax=int(H*2))
    for c in cs: c['H']=H
    classify(cs,thr)
    ls=[]
    for t,x,y in G.lines(cs,H=H):
        for k,v in FIX.items(): t=t.replace(k,v)
        ls.append((t,x,y))
    return ls
if __name__=="__main__":
    out={}
    for sh in sys.argv[2:]:
        lay=tuple(sys.argv[1].split(','))
        ls=run(sh,lay,H=21)
        full=[];cnt=[];sp=[]
        for t,x,y in ls:
            m=SL.search(t)
            if m:
                n,d,s,Lc=map(int,m.groups())
                if d in (8,10,12,14,16,18,20,22,25) and n<=300 and 30<=Lc<=2500: full.append((n,d,s,Lc,t)); continue
            m=CNT.search(t)
            if m:
                n,d,Lc=map(int,m.groups())
                if d in (8,10,12,14,16,18,20,22,25,28,32) and n<=40 and 30<=Lc<=2500: cnt.append((n,d,Lc,t)); continue
            m=SP.search(t)
            if m:
                d,s,Lc=map(int,m.groups())
                if d in (8,10,12,14,16,18,20) and 30<=Lc<=2500: sp.append((d,s,Lc,t))
        kg_full=sum(n*Lc/100*W(d) for n,d,s,Lc,_ in full); kg_cnt=sum(n*Lc/100*W(d) for n,d,Lc,_ in cnt)
        out[sh]=dict(lines=len(ls),full=full,cnt=cnt,sp=sp,kg_full=kg_full,kg_cnt=kg_cnt)
        print(sh,"lines",len(ls),"full",len(full),f"{kg_full:,.0f}kg","cnt",len(cnt),f"{kg_cnt:,.0f}kg","spacing-only",len(sp))
    pickle.dump(out,open(O+f'rebar_{sys.argv[2]}.pkl','wb'))
