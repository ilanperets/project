import pymupdf as fitz, sys, collections, glob
for p in sorted(sys.argv[1:]):
    d=fitz.open(p); pg=d[0]
    ocgs=d.get_ocgs()
    w=pg.get_text('words')
    txt=" ".join(x[4] for x in w)[:110]
    print(f"{p.split('/')[-1]:18} {pg.rect.width:5.0f}x{pg.rect.height:<5.0f} ocg={len(ocgs):3} words={len(w):5} | {txt}")
