import pdfplumber,sys,json,math,numpy as np,cv2
from shapely.geometry import Polygon,MultiPolygon
from shapely.ops import unary_union
K=sys.argv[1]; OUT=sys.argv[2]
CM=0.35278*50/10   # cm per pt at 1:50  (verified: 1210cm dim = 686.9pt)
BB=(590,70,1350,1060)
def inbb(o): return o['x0']>=BB[0] and o['x1']<=BB[2] and o['top']>=BB[1] and o['bottom']<=BB[3]
res={}
for sh in ['ק-2','ק-3','ק-4']:
    p=pdfplumber.open(f'{K}/{sh}.pdf').pages[0]
    grays=[c for c in p.curves+p.rects if c.get('fill') and str(c.get('non_stroking_color')).startswith('(0.596') and inbb(c)]
    polys=[]
    for g in grays:
        pts=g.get('pts') or [(g['x0'],g['top']),(g['x1'],g['top']),(g['x1'],g['bottom']),(g['x0'],g['bottom'])]
        pts=[(x*CM,y*CM) for x,y in pts]
        if len(pts)>=3:
            pg=Polygon(pts).buffer(0)
            if pg.area>10: polys.append(pg)
    U=unary_union(polys); parts=list(U.geoms) if isinstance(U,MultiPolygon) else ([U] if not U.is_empty else [])
    els=[]
    for pg in parts:
        A=pg.area/1e4; P=pg.length/100
        r=pg.minimum_rotated_rectangle; xs=r.exterior.coords
        s=sorted([math.dist(xs[0],xs[1]),math.dist(xs[1],xs[2])])
        t=2*A/P if P else 0
        kind='עמוד' if (s[1]<=65 and s[0]<=65) else 'קיר'
        els.append(dict(kind=kind,area_m2=round(A,3),t_cm=round(t*100) if kind=='קיר' else None,dims_cm=[round(s[0]),round(s[1])],len_m=round(A/t,2) if kind=='קיר' and t else None,bbox=[round(v) for v in pg.bounds]))
    # slab outline from thick lines
    thick=[l for l in p.lines+p.curves+p.rects if (l.get('linewidth') or 0)>=1.5 and inbb(l) and not l.get('fill')]
    sc=0.5 # px per cm
    W=int((BB[2]-BB[0])*CM*sc)+4; H=int((BB[3]-BB[1])*CM*sc)+4
    img=np.zeros((H,W),np.uint8)
    def tp(x,y): return (int((x-BB[0])*CM*sc)+2,int((y-BB[1])*CM*sc)+2)
    for l in thick:
        pts=l.get('pts') or [(l['x0'],l['top']),(l['x1'],l['bottom'])]
        for a,b in zip(pts,pts[1:]): cv2.line(img,tp(*a),tp(*b),255,1)
    for pg in parts:
        cv2.fillPoly(img,[np.array([( int((x/CM-BB[0])*CM*sc)+2,int((y/CM-BB[1])*CM*sc)+2) for x,y in pg.exterior.coords],np.int32)],255)
    k=cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(9,9))  # ~18cm gaps
    closed=cv2.morphologyEx(img,cv2.MORPH_CLOSE,k)
    ff=closed.copy(); m=np.zeros((H+2,W+2),np.uint8); cv2.floodFill(ff,m,(0,0),128)
    inside=(ff!=128)
    # keep largest component
    n,lab,st,_=cv2.connectedComponentsWithStats(inside.astype(np.uint8))
    big=1+np.argmax(st[1:,cv2.CC_STAT_AREA]); mask=(lab==big)
    area=mask.sum()/(sc*sc)/1e4
    ys,xs=np.where(mask)
    vis=cv2.cvtColor(img,cv2.COLOR_GRAY2BGR); vis[mask&(img==0)]=(200,230,255)
    cv2.imwrite(f'{OUT}/slab_{sh}.png',vis)
    res[sh]=dict(gray_parts=len(parts),walls=[e for e in els if e['kind']=='קיר'],cols=[e for e in els if e['kind']=='עמוד'],
                 wall_area=round(sum(e['area_m2'] for e in els if e['kind']=='קיר'),3),col_area=round(sum(e['area_m2'] for e in els if e['kind']=='עמוד'),3),
                 slab_outline_m2=round(area,1),slab_bbox_m=[round((xs.max()-xs.min())/sc/100,2),round((ys.max()-ys.min())/sc/100,2)])
json.dump(res,open(f'{OUT}/struct.json','w'),ensure_ascii=False,indent=1)
for sh,r in res.items():
    print(sh,'gray parts',r['gray_parts'],'walls m2',r['wall_area'],'cols m2',r['col_area'],'ncols',len(r['cols']),'slab outline',r['slab_outline_m2'],'bbox',r['slab_bbox_m'])
    for w in sorted(r['walls'],key=lambda e:-e['area_m2']): print('   wall',w['area_m2'],'t',w['t_cm'],'L',w['len_m'],w['dims_cm'])
    print('   cols',[c['dims_cm'] for c in r['cols']])
