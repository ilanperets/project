import sys, pickle, re, numpy as np, collections
sys.path.insert(0,'/tmp/claude-0/-home-claude/90f9075a-8e8a-5948-8a8e-80f1167be059/scratchpad/scripts')
import glyphs as G
O='/tmp/claude-0/-home-claude/90f9075a-8e8a-5948-8a8e-80f1167be059/scratchpad/hofim/'
BD="/tmp/claude-0/-home-claude/90f9075a-8e8a-5948-8a8e-80f1167be059/scratchpad/corpus/hadera/T1222_hofim_highschool/קונסטרוקציה מבנה B_x/קונסטלציה מבנה B/מבנה B/CONST_B_%s.pdf"
LAB={4:'Φ',0:'1',5:'0',6:'@',1:'1',7:'0',18:'L',8:'3',9:'8',10:'0',55:'Φ',52:'1',56:'2',57:'@',53:'1',58:'0',71:'4',75:'8',76:'0',
     37:'2',38:'Φ',48:'Φ',41:'1',49:'2',50:'@',42:'1',51:'0',64:'4',67:'8',68:'0',59:'4',60:'8',61:'0',100:'Φ',102:'6',103:'0',111:'5',112:'5',
     116:'Φ',114:'1',117:'0',118:'@',119:'2',120:'0',129:'1',130:'7',131:'0',148:'Φ',147:'1',149:'2',150:'@',151:'2',152:'0',122:'8',121:'1',124:'8',123:'Φ',
     133:'4',134:'8',135:'0',70:'L',62:'L',113:'L',132:'L',136:'L'}
def f(m): return G.nfeat(m)[:-1]
def exemplars():
    gs=pickle.load(open(O+'crop260.pkl','rb'))
    ex=[(f(gs[i]['m']),t) for i,t in LAB.items()]
    g2=pickle.load(open(O+'crop230.pkl','rb'))
    L2={16:'5',20:'5',24:'3',23:'0',25:'0',41:'3',47:'5',50:'8',51:'8',52:'0',18:'4',44:'4',19:'@',45:'@',28:'1',29:'1',30:'1',32:'1',43:'1',46:'1',21:'L',48:'L'}
    ex+=[(f(g2[i]['m']),t) for i,t in L2.items()]
    # augmentation: small rotations and dilation
    from PIL import Image
    from scipy import ndimage as ndi
    aug=[]
    src=[(gs[i]['m'],t) for i,t in LAB.items()]+[(g2[i]['m'],t) for i,t in L2.items()]
    for m,t in src:
        for ang in (-6,-3,3,6):
            im=Image.fromarray((m*255).astype(np.uint8)).rotate(ang,expand=True,resample=Image.BILINEAR)
            mm=np.array(im)>100; ys,xs=np.nonzero(mm)
            if len(ys)==0: continue
            mm=mm[ys.min():ys.max()+1,xs.min():xs.max()+1]; aug.append((f(mm),t))
        aug.append((f(ndi.binary_dilation(m)),t)); aug.append((f(ndi.binary_erosion(m) if m.sum()>80 else m),t))
    return ex+aug
EX=exemplars()
EM=np.stack([e for e,_ in EX]); ET=[t for _,t in EX]
def dist(m):
    v=f(m); d=np.abs(EM-v).sum(1); i=int(d.argmin()); return (float(d[i]),ET[i])
def crop(mm):
    rows=np.nonzero(mm.any(axis=1))[0]; cols=np.nonzero(mm.any(axis=0))[0]
    if len(rows)==0: return None
    return mm[rows[0]:rows[-1]+1,cols[0]:cols[-1]+1]
def brute(m, thr=30):
    h,w=m.shape; best=(1e9,'?')
    for x in range(8,w-7):
        a=crop(m[:,:x]); b=crop(m[:,x:])
        if a is None or b is None: continue
        da,ta=dist(a); db,tb=dist(b)
        if da<thr and db<thr and da+db<best[0]: best=(da+db,ta+tb)
    if best[1]!='?' or w<70: return best[1]
    for x in range(8,w-30,2):
        a=crop(m[:,:x])
        if a is None: continue
        da,ta=dist(a)
        if da>=thr: continue
        for y in range(x+8,w-7,2):
            b=crop(m[:,x:y]); c=crop(m[:,y:])
            if b is None or c is None: continue
            db,tb=dist(b); dc,tc=dist(c)
            if db<thr and dc<thr and da+db+dc<best[0]: best=(da+db+dc,ta+tb+tc)
    return best[1]
def dpsplit(m, thr=30):
    r=_dpsplit(m,thr)
    return r if '?' not in r else brute(m,thr)
def _dpsplit(m, thr=30):
    h,w=m.shape; prof=m.sum(axis=0)
    cand=[0]+[x for x in range(3,w-3) if prof[x]<=max(2,prof.min()+1) or (prof[x]<prof[x-1] and prof[x]<=prof[x+1] and prof[x]<=4)]+[w]
    cand=sorted(set(cand))
    best={0:(0.0,'')}
    for j in cand[1:]:
        for i in cand:
            if i>=j or i not in best: continue
            if j-i<8 or j-i>52: continue
            mm=m[:,i:j]; rows=np.nonzero(mm.any(axis=1))[0]
            if len(rows)==0: continue
            d,t=dist(mm[rows[0]:rows[-1]+1])
            if d>=thr: continue
            sc=best[i][0]+d
            if j not in best or sc<best[j][0]: best[j]=(sc,best[i][1]+t)
    return best[w][1] if w in best else '?'
def cls(m,thr=30):
    d,t=dist(m)
    return t if d<thr else '?'
W=lambda d:0.00617*d*d
def lines_of(a):
    cs,_=G.comps(a,hmin=12,hmax=70)
    out=[]
    for c in cs:
        if c['kind']=='dot': c['t']='.'; continue
        h=c['y1']-c['y0']; w=c['x1']-c['x0']
        if h>58 and w>58: c['t']='#'; continue
        if h<12 and 14<w<30: c['t']='-'; continue
        if h<25: c['t']='.' if w<14 else '?'; continue
        t=cls(c['m'])
        if t=='?' and w>30:
            t=dpsplit(c['m'])
        c['t']=t
    return G.lines(cs)
FULL=re.compile(r'(\d{1,3})\s*Φ\s*(\d{1,2})\s*@\s*(\d{1,2})\s*L\s*=+\s*(\d{2,4})(?:\s*-\s*(\d{2,4}))?')
CNT=re.compile(r'(\d{1,2})\s*Φ\s*(\d{1,2})\s*L\s*=+\s*(\d{2,4})')
SP=re.compile(r'Φ\s*(\d{1,2})\s*@\s*(\d{1,2})\s*L\s*=+\s*(\d{2,4})')
ANG=(0,90,270,16,196,286,106)
DIAS=(8,10,12,14,16,18,20,22,25,28,32)
def join2(ls):
    out=list(ls); used=set()
    Ls=[(i,t,x,y) for i,(t,x,y) in enumerate(ls) if re.match(r'^[#?.\s]*L\s*=',t)]
    for i,(t,x,y) in enumerate(ls):
        if re.search(r'Φ\s*\d{1,2}(\s*@\s*\d{1,2})?\s*$',t) and 'L' not in t:
            best=None
            for j,tl,xl,yl in Ls:
                if j in used: continue
                dy=yl-y; dx=xl-x
                if 25<dy<90 and -60<dx<160:
                    if best is None or dy<best[0]: best=(dy,j,tl)
            if best:
                used.add(best[1]); out.append((t+' '+best[2].replace('#','').strip(),x,y))
    return out
def parse(ls):
    ls=join2(ls)
    full=[];cnt=[];sp=[]
    for t,x,y in ls:
        t2=t.replace('#','')
        m=FULL.search(t2)
        if m:
            n,d,s,L=map(int,m.groups()[:4])
            if m.group(5): L=(L+int(m.group(5)))//2
            if d in DIAS and 1<=n<=300 and 30<=L<=2500 and s in (5,7,8,10,12,15,20,25,30,40,50,60): full.append((n,d,s,L,t)); continue
        m=CNT.search(t2)
        if m:
            n,d,L=map(int,m.groups())
            if d in DIAS and 1<=n<=60 and 30<=L<=2500: cnt.append((n,d,L,t)); continue
        m=SP.search(t2)
        if m:
            d,s,L=map(int,m.groups())
            if d in DIAS and 30<=L<=2500: sp.append((d,s,L,t))
    return full,cnt,sp
def run(sh, layers):
    res=dict(full=[],cnt=[],sp=[])
    for rot in ANG:
        a=G.render_angle(BD%sh,layers,500,rot)
        fu,cn,spp=parse(lines_of(a))
        res.setdefault('passes',{})[rot]=(fu,cn,spp)
        res['full']+=fu; res['cnt']+=cn; res['sp']+=spp
        if rot==0:
            cs,_=G.comps(a,hmin=12,hmax=80); res['marks']=sum(1 for c in cs if c['kind']=='g' and 58<(c['y1']-c['y0'])<80 and 58<(c['x1']-c['x0'])<80)
        del a
    return res
if __name__=="__main__":
    lay=tuple(sys.argv[1].split(','))
    allr={}
    for sh in sys.argv[2:]:
        r=run(sh,lay); allr[sh]=r
        kf=sum(n*L/100*W(d) for n,d,s,L,_ in r['full']); kc=sum(n*L/100*W(d) for n,d,L,_ in r['cnt'])
        print(sh,"marks",r.get('marks'),"full",len(r['full']),f"{kf:,.0f}kg","cnt",len(r['cnt']),f"{kc:,.0f}kg","sp",len(r['sp']),flush=True)
    pickle.dump(allr,open(O+f'fb_{sys.argv[2]}.pkl','wb'))
