import sys, math, json, numpy as np, re
sys.path.insert(0,'/tmp/claude-0/-home-claude/90f9075a-8e8a-5948-8a8e-80f1167be059/scratchpad/scripts')
import pymupdf as fitz, pytesseract
from PIL import Image
from scipy import ndimage as ndi
import hofim_vert2 as V
BD="/tmp/claude-0/-home-claude/90f9075a-8e8a-5948-8a8e-80f1167be059/scratchpad/corpus/hadera/T1222_hofim_highschool/קונסטרוקציה מבנה B_x/קונסטלציה מבנה B/מבנה B/CONST_B_%s.pdf"
O="/tmp/claude-0/-home-claude/90f9075a-8e8a-5948-8a8e-80f1167be059/scratchpad/hofim/"
CM=2.0; z=75*0.03528/CM
def markers(src):
    pts=[]
    for d in src.get_drawings():
        if d['layer']=='MIFLAS' and d['rect'].width<14 and d['rect'].height<14 and d['rect'].x0>290:
            pts.append(((d['rect'].x0+d['rect'].x1)/2,(d['rect'].y0+d['rect'].y1)/2))
    cl=[]
    for p in pts:
        for c in cl:
            if math.hypot(c[0]-p[0],c[1]-p[1])<8: break
        else: cl.append(p)
    return cl
def diagonals(src):
    out=[]
    for d in src.get_drawings():
        if d['layer'] in('s_help',) and d['type']=='s':
            for it in d['items']:
                if it[0]=='l' and abs(it[2]-it[1])>60: out.append((it[1],it[2]))
    return out
def boundary(src, extraH=None):
    def p(d):
        if d['layer'] in ('s_beam','s_wall_DOWN','S_WALL_UP','S_Col_Up','s-solid','S-BEAM','1-BEAM') : return d['items']
        return None
    _,pg=V.replay(src,p,width=0.8,fill=False); Bd=V.raster(pg,75,0)
    def pf(d): return d['items'] if d['layer']=='s-solid' and 'f' in d['type'] else None
    _,pg2=V.replay(src,pf); Bd|=V.raster(pg2,75,0)
    if extraH is not None: Bd|=extraH
    return Bd
def ocr_marker(src, m, ang):
    # crop around marker, rotate so text horizontal
    R=fitz.Rect(m[0]-15,m[1]-60,m[0]+90,m[1]+15)
    best=None
    pg=src
    for a in (ang, ang+180):
        clip=fitz.Rect(m[0]-70,m[1]-70,m[0]+70,m[1]+70)
        pix=pg.get_pixmap(clip=clip,dpi=300,colorspace=fitz.csGRAY)
        im=Image.frombytes("L",[pix.width,pix.height],pix.samples).rotate(a,expand=True,fillcolor=255)
        t=pytesseract.image_to_string(im,config='--psm 6')
        mm=re.search(r'D\s*=\s*(\d{2})(\s*\+\s*(\d))?',t)
        ok=re.search(r'K\.?\s*[=:]?\s*([+\-—–]?\s*\d{1,2}[.,]\d{2})',t)
        if mm: 
            best=(int(mm.group(1))+(int(mm.group(3)) if mm.group(3) else 0), ok.group(1) if ok else None, t.replace('\n',' | ')[:80]); break
    return best
if __name__=="__main__":
    sh=sys.argv[1]
    src=fitz.open(BD%sh)[0]
    ms=markers(src); dg=diagonals(src)
    print(sh,"markers",len(ms),"diagonals",len(dg))
    shp=None
    R=json.load(open(O+'walls_raw.json'))
    Bd=boundary(src)
    Bd=ndi.binary_dilation(Bd,iterations=1)
    lab,n=ndi.label(~Bd)
    areas=ndi.sum(np.ones_like(lab),lab,range(n+1))
    res=[]
    for m in ms:
        # nearest diagonal angle
        best=None
        for a,b in dg:
            # distance point-segment
            v=b-a; w=fitz.Point(m)-a; t=max(0,min(1,(w.x*v.x+w.y*v.y)/(v.x**2+v.y**2))); q=a+v*t
            dd=math.hypot(q.x-m[0],q.y-m[1])
            if best is None or dd<best[0]: best=(dd,math.degrees(math.atan2(v.y,v.x)),(a,b))
        ang=best[1] if best and best[0]<6 else 0
        x,y=int(m[0]*z),int(m[1]*z)
        # seed slightly off the marker (marker drawn in MIFLAS not in boundary) 
        L=lab[y,x]; area=areas[L]*CM*CM/1e4 if L>0 else 0
        res.append(dict(m=m,ang=ang,label=int(L),area=float(area)))
    print("regions",len(set(r['label'] for r in res)), "sum unique area", round(sum({r['label']:r['area'] for r in res if r['area']<600}.values()),1))
    for r in res[:60]: print(f"  ({r['m'][0]:.0f},{r['m'][1]:.0f}) ang {r['ang']:.0f} L{r['label']} area {r['area']:.1f}")
    np.save(O+f'slab_lab_{sh}.npy',lab); json.dump(res,open(O+f'slab_{sh}.json','w'))
