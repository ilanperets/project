import pdfplumber,sys,numpy as np,cv2,math,json
K,O=sys.argv[1:]
CM=0.35278*50/10; BB=(590,40,1360,1060); s=0.5
out={}
for sh in ['ק-2','ק-3','ק-4']:
    p=pdfplumber.open(f'{K}/{sh}.pdf').pages[0]
    segs=[]
    for l in p.lines+p.curves+p.rects:
        lw=round(l.get('linewidth') or 0,2)
        pts=l.get('pts') or [(l['x0'],l['top']),(l['x1'],l['top']),(l['x1'],l['bottom']),(l['x0'],l['bottom']),(l['x0'],l['top'])]
        if not all(BB[0]<=x<=BB[2] and BB[1]<=y<=BB[3] for x,y in pts): continue
        gray=l.get('fill') and str(l.get('non_stroking_color')).startswith('(0.596')
        if l.get('fill') and not gray: continue
        for a,b in zip(pts,pts[1:]): segs.append((lw,a,b,gray))
    # structural extent = gray + magenta(1.42) + long green(0.42) h/v lines
    st=[(a,b) for lw,a,b,g in segs if g or lw==1.42 or (lw==0.42 and math.dist(a,b)>40)]
    xs=[v for a,b in st for v in (a[0],b[0])]; ys=[v for a,b in st for v in (a[1],b[1])]
    tol=25/CM  # 25cm
    ex=(min(xs)-tol,min(ys)-tol,max(xs)+tol,max(ys)+tol)
    W=int((BB[2]-BB[0])*CM*s)+10;H=int((BB[3]-BB[1])*CM*s)+10
    img=np.zeros((H,W),np.uint8)
    tp=lambda x,y:(int((x-BB[0])*CM*s)+5,int((y-BB[1])*CM*s)+5)
    inside=lambda q: ex[0]<=q[0]<=ex[2] and ex[1]<=q[1]<=ex[3]
    kept=0
    for lw,a,b,g in segs:
        if lw==1.13: continue
        L=math.dist(a,b)
        if L<12 and not g: continue
        if lw==0.92 and not (inside(a) and inside(b)): continue
        cv2.line(img,tp(*a),tp(*b),255,1); kept+=1
    for lw,a,b,g in segs:
        pass
    cl=cv2.morphologyEx(img,cv2.MORPH_CLOSE,cv2.getStructuringElement(cv2.MORPH_RECT,(11,11)))
    ff=cl.copy(); m=np.zeros((H+2,W+2),np.uint8); cv2.floodFill(ff,m,(0,0),128)
    ins=(ff!=128).astype(np.uint8)
    ins=cv2.morphologyEx(ins,cv2.MORPH_OPEN,cv2.getStructuringElement(cv2.MORPH_RECT,(21,21)))
    n,lab,stt,_=cv2.connectedComponentsWithStats(ins); big=1+np.argmax(stt[1:,cv2.CC_STAT_AREA]); mask=(lab==big)
    A=mask.sum()/(s*s)/1e4; yy,xx=np.where(mask)
    vis=cv2.cvtColor(img,cv2.COLOR_GRAY2BGR); vis[mask&(img==0)]=(210,235,255)
    cv2.imwrite(f'{O}/outline3_{sh}.png',vis); np.save(f'{O}/mask_{sh}.npy',mask)
    out[sh]=dict(outline_m2=round(float(A),1),w=round(float(xx.max()-xx.min())/s/100,2),h=round(float(yy.max()-yy.min())/s/100,2),extent_m=[round((ex[2]-ex[0])*CM/100-0.5,2),round((ex[3]-ex[1])*CM/100-0.5,2)])
    print(sh,out[sh])
json.dump(out,open(f'{O}/outline.json','w'))
