import json,sys,collections,re,math
db=json.load(open(sys.argv[1])); E=[e for e in db['entities'] if e['ownerBlockRecordSoftId']=='70']
clean=lambda t: re.sub(r'\\f[^;]*;','',t or '').replace('\\P',' ').strip()
def poly(h):
    out=[]
    for p in h['boundaryPaths']:
        pts=[(ed['start']['x'],ed['start']['y']) for ed in p['edges']]
        out.append(pts)
    return out
def area(pts): return abs(sum(pts[i][0]*pts[i-1][1]-pts[i-1][0]*pts[i][1] for i in range(len(pts))))/2
def perim(pts): return sum(math.dist(pts[i],pts[i-1]) for i in range(len(pts)))
def inside(pt,pts):
    x,y=pt;c=False
    for i in range(len(pts)):
        x1,y1=pts[i-1];x2,y2=pts[i]
        if (y1>y)!=(y2>y) and x<(x2-x1)*(y-y1)/(y2-y1)+x1: c=not c
    return c
# walls
walls=collections.defaultdict(lambda:[0,0,0]); raw=[]
for h in E:
    if h['type']=='HATCH' and h['layer']=='A-WALL-PATT':
        for pts in poly(h):
            A=area(pts);P=perim(pts);s=P/2;d=s*s-4*A
            t=(s-math.sqrt(max(d,0)))/2; L=A/t if t>0 else 0
            tk=int(round(t/10)*10); walls[tk][0]+=1; walls[tk][1]+=L; walls[tk][2]+=A
print('WALLS (hatched) thickness_mm: count, length_m, area_m2')
for k in sorted(walls): print(' ',k, walls[k][0], round(walls[k][1]/1000,2), round(walls[k][2]/1e6,2))
# floor zones
zones=[]
for h in E:
    if h['type']=='HATCH' and h['layer']=='A-FLOR-PATT':
        for pts in poly(h): zones.append(dict(pat=h['patternName'],pts=pts,A=area(pts)/1e6,P=perim(pts)/1000))
# rooms
T=[(e['insertionPoint']['x'],e['insertionPoint']['y'],clean(e['text'])) for e in E if e['type']=='MTEXT' and e['layer']=='A-AREA-IDEN']
nums=[t for t in T if re.fullmatch(r'[\d-]+',t[2])]; names=[t for t in T if t not in nums and t[2] not in ('.','ח')]
rooms=[]
for n in nums:
    nm=min(names,key=lambda t:abs(t[1]-n[1]-414)*3+abs(t[0]-n[0]))
    label=nm[2]
    if label in('רופאים','מנהל'): label='ח. '+label
    z=[z for z in zones if inside((n[0],n[1]),z['pts'])]
    rooms.append((n[2],label,round(z[0]['A'],2) if z else None,round(z[0]['P'],2) if z else None,z[0]['pat'] if z else None))
print('ROOMS'); [print(' ',r) for r in sorted(rooms)]
print('zones total', len(zones), round(sum(z['A'] for z in zones),2))
# doors
dc=collections.Counter()
for e in E:
    if e['type']=='INSERT' and e['layer']=='A-DOOR':
        n=e['name'].split('-5')[0] if False else e['name']
        m=re.match(r'(עץ-ציר|עץ-דו-כנפית) - (\d+)_(\d+)',n)
        if m: dc[(m.group(1),m.group(2)+'/'+m.group(3))]+=1
        elif 'Gilgen140' in n: dc[('דלת אוטומטית Gilgen','140')]+=1
        elif 'Gilgen' in n: dc[('דלת אוטומטית Gilgen','סטנדרט')]+=1
        elif 'CurtainDoor' in n: dc[('דלת זכוכית ללא מסגרת','—')]+=1
        else: dc[('?',n)]+=1
print('DOORS'); [print(' ',k,v) for k,v in sorted(dc.items())]
cnt=lambda L: collections.Counter(re.sub(r'-(\d{6,7}|V\d+)-.*$','',e['name']) for e in E if e['type']=='INSERT' and e['layer']==L)
for L in ['A-GLAZ-CURT','A-GLAZ-CWMG','S-COLS','P-SANR-FIXT','E-ELEC-FIXT','Q-SPCQ','I-FURN','A-DETL','A-DETL-GENF','Q-CASE']: print(L, dict(cnt(L)))
