import pymupdf as fitz, sys
from PIL import Image, ImageDraw
pdf,out=sys.argv[1],sys.argv[2]; dpi=int(sys.argv[3]) if len(sys.argv)>3 else 30
pg=fitz.open(pdf)[0]; k=dpi/72; M=pg.rotation_matrix
W,H=int(pg.rect.width*k)+1,int(pg.rect.height*k)+1
im=Image.new("RGB",(W,H),"white"); d=ImageDraw.Draw(im)
STY={'s-solid':((220,60,50),None),'S_HATCH':((60,110,220),None),'s_wall_DOWN':((40,150,70),None),'S_WALL_UP':((240,150,0),None),'S_Col_Up':((160,60,200),None),'s_beam':((150,150,150),None),'IZ  wall-0.6':((0,180,200),None),'S_Col_Down':((90,60,20),None)}
order=['s_beam','IZ  wall-0.6','S_HATCH','s_wall_DOWN','S_WALL_UP','S_Col_Up','S_Col_Down','s-solid']
dr=pg.get_drawings()
for L in order:
    c=STY[L][0]
    for x in dr:
        if x['layer']!=L: continue
        pts=[]
        for it in x['items']:
            if it[0]=='l': seg=[it[1],it[2]]
            elif it[0]=='c': seg=[it[1],it[4]]
            elif it[0]=='re': r=it[1]; seg=[r.tl,r.tr,r.br,r.bl,r.tl]
            elif it[0]=='qu': q=it[1]; seg=[q.ul,q.ur,q.lr,q.ll,q.ul]
            else: continue
            seg=[(p*M) for p in seg]; seg=[(p.x*k,p.y*k) for p in seg]
            if 'f' in x['type'] and it[0] in('re','qu'): d.polygon(seg,fill=c)
            else: d.line(seg,fill=c,width=1)
            pts+=seg
        if 'f' in x['type'] and len(pts)>=3 and all(it[0] in 'lc' for it in x['items']): d.polygon(pts,fill=c)
im.save(out)
