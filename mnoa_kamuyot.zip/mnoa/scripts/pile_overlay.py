import pymupdf as fitz, json, sys
from PIL import Image, ImageDraw, ImageEnhance
pdf,js,out,crop=sys.argv[1],sys.argv[2],sys.argv[3],[float(x) for x in sys.argv[4].split(',')]
pg=fitz.open(pdf)[0]; R=pg.rect
clip=fitz.Rect(R.width*crop[0],R.height*crop[1],R.width*crop[2],R.height*crop[3])
dpi=int(sys.argv[5]); k=dpi/72
pix=pg.get_pixmap(clip=clip,dpi=dpi)
im=Image.frombytes("RGB",[pix.width,pix.height],pix.samples)
im=Image.blend(im,Image.new("RGB",im.size,"white"),0.55)
d=ImageDraw.Draw(im)
col={50:(46,125,79),60:(25,90,170),70:(178,58,43)}
for p in json.load(open(js)):
    q=fitz.Point(p['x'],p['y'])*pg.rotation_matrix; x=(q.x-clip.x0)*k; y=(q.y-clip.y0)*k; r=max(7,p['dia']/100*12*k*1.0)
    r=9 if p['dia']==60 else (7 if p['dia']==50 else 11)
    c=col[p['dia']]
    d.ellipse([x-r,y-r,x+r,y+r],outline=c,width=3)
    if p.get('est'): d.ellipse([x-r-4,y-r-4,x+r+4,y+r+4],outline=(154,106,0),width=2)
im.convert("RGB").save(out,quality=82); print(im.size)
