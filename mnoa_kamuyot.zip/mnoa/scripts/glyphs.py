import sys, json, numpy as np, pymupdf as fitz
from scipy import ndimage as ndi
from PIL import Image, ImageDraw
sys.path.insert(0,'/tmp/claude-0/-home-claude/90f9075a-8e8a-5948-8a8e-80f1167be059/scratchpad/scripts')
GW,GH=10,16
def render(path, layers, dpi=300, rot_extra=0):
    src=fitz.open(path)[0]
    nd=fitz.open(); pg=nd.new_page(width=src.mediabox.width,height=src.mediabox.height); sh=pg.new_shape()
    for d in src.get_drawings():
        if d['layer'] not in layers: continue
        for it in d['items']:
            if it[0]=='l': sh.draw_line(it[1],it[2])
            elif it[0]=='c': sh.draw_bezier(*it[1:5])
            elif it[0]=='re': sh.draw_rect(it[1])
            elif it[0]=='qu': sh.draw_quad(it[1])
        sh.finish(color=(0,0,0),width=0.7)
    sh.commit(); pg.set_rotation((src.rotation+rot_extra)%360)
    pix=pg.get_pixmap(dpi=dpi,colorspace=fitz.csGRAY)
    return np.frombuffer(pix.samples,np.uint8).reshape(pix.height,pix.width)<128
def comps(a, hmin=14, hmax=70):
    lab,n=ndi.label(a,structure=np.ones((3,3)))
    out=[]
    for i,sl in enumerate(ndi.find_objects(lab),1):
        h=sl[0].stop-sl[0].start; w=sl[1].stop-sl[1].start
        if h<4 and w<4: 
            out.append(dict(i=i,y0=sl[0].start,y1=sl[0].stop,x0=sl[1].start,x1=sl[1].stop,kind='dot')); continue
        if h>hmax or w>hmax*1.5: continue
        m=(lab[sl]==i)
        out.append(dict(i=i,y0=sl[0].start,y1=sl[0].stop,x0=sl[1].start,x1=sl[1].stop,kind='g',m=m))
    return out,lab
def feat(m):
    im=Image.fromarray((m*255).astype(np.uint8)).resize((GW,GH),Image.BILINEAR)
    return (np.array(im)/255.0).ravel()
def fvec(c):
    m=c['m']; h,w=m.shape
    return np.concatenate([feat(m), [w/h*0.8, ]])
def cluster(cs, thr=2.2, protos=None):
    protos=protos or []  # list of (vec, h, members)
    for c in cs:
        if c['kind']!='g': continue
        v=fvec(c); h=c['y1']-c['y0']
        best=None
        for k,p in enumerate(protos):
            if abs(p['h']-h)>0.35*max(p['h'],h) and not (h<12 and p['h']<12): continue
            d=np.abs(p['v']-v).sum()
            if best is None or d<best[0]: best=(d,k)
        if best and best[0]<thr: c['cl']=best[1]; protos[best[1]]['n']+=1
        else: protos.append(dict(v=v,h=h,n=1,ex=c['m'])); c['cl']=len(protos)-1
    return protos
def montage(protos, path, cols=20):
    cell=70; rows=(len(protos)+cols-1)//cols
    im=Image.new("L",(cols*cell,rows*cell),255); dr=ImageDraw.Draw(im)
    for k,p in enumerate(protos):
        m=p['ex']; g=Image.fromarray(((~m)*255).astype(np.uint8))
        g.thumbnail((cell-14,cell-18))
        x,y=(k%cols)*cell,(k//cols)*cell
        im.paste(g,(x+4,y+14)); dr.text((x+2,y+1),f"{k}:{p['n']}",fill=0)
    im.save(path)
def nfeat(m, S=16):
    h,w=m.shape; s=max(h,w)
    pad=np.zeros((s,s),bool); oy=(s-h)//2; ox=(s-w)//2; pad[oy:oy+h,ox:ox+w]=m
    im=Image.fromarray((pad*255).astype(np.uint8)).resize((S,S),Image.BILINEAR)
    f=np.array(im)/255.0
    return np.concatenate([f.ravel(),[w/h*2.0, h/40.0*2.0]])
def cluster2(cs, thr=14.0):
    P=[]
    for c in cs:
        if c['kind']!='g': continue
        h=c['y1']-c['y0']; w=c['x1']-c['x0']
        if h>48 and w>48: c['cl']=-2; continue   # circled marks
        v=nfeat(c['m']); best=None
        for k,p in enumerate(P):
            d=np.abs(p['v']-v).sum()
            if best is None or d<best[0]: best=(d,k)
        if best and best[0]<thr:
            c['cl']=best[1]; p=P[best[1]]; p['n']+=1
        else:
            P.append(dict(v=v,n=1,ex=c['m'])); c['cl']=len(P)-1
    return P
def classify(cs, P, labels, thr=22):
    lab_ids=[int(k) for k in labels]
    for c in cs:
        if c['kind']=='dot': c['t']='.'; continue
        if c.get('cl')==-2: c['t']='#'; continue
        k=c.get('cl')
        if k is not None and str(k) in labels: c['t']=labels[str(k)]; continue
        v=nfeat(c['m']); best=None
        for j in lab_ids:
            d=np.abs(P[j]['v']-v).sum()
            if best is None or d<best[0]: best=(d,j)
        c['t']=labels[str(best[1])] if best and best[0]<thr else '?'
def lines(cs, H=40):
    gs=[c for c in cs if 't' in c]
    for c in gs: c['yc']=(c['y0']+c['y1'])/2; c['h']=c['y1']-c['y0']
    # merge '-' pairs into '='
    dash=[c for c in gs if c['t'] in '-']
    used=set()
    for i,a in enumerate(dash):
        for b in dash[i+1:]:
            if id(b) in used or id(a) in used: continue
            if abs(a['x0']-b['x0'])<8 and abs(a['x1']-b['x1'])<8 and 4<abs(a['yc']-b['yc'])<20:
                a['t']='='; a['y0']=min(a['y0'],b['y0']); a['y1']=max(a['y1'],b['y1']); a['yc']=(a['y0']+a['y1'])/2; used.add(id(b))
    gs=[c for c in gs if id(c) not in used]
    big=[c for c in gs if c['t'] not in '.-=_\'' ]
    big.sort(key=lambda c:(c['x0']))
    rows=[]
    for c in sorted(gs,key=lambda c:c['x0']):
        ref=c['yc']
        for r in rows:
            last=r[-1]
            if abs(r[0]['yc_line']-ref)<14 and c['x0']-last['x1']<45 and c['x0']>=last['x0']-2:
                r.append(c); break
        else:
            c['yc_line']=ref; rows.append([c])
        if 'yc_line' not in c: c['yc_line']=rows[-1][0]['yc_line'] if c in rows[-1] else ref
    out=[]
    for r in rows:
        s=''; prev=None
        for c in r:
            if prev is not None and c['x0']-prev['x1']>16: s+=' '
            s+=c['t']; prev=c
        out.append((s, r[0]['x0'], r[0]['yc_line']))
    return out

def render_angle(path, layers, dpi, angle):
    src=fitz.open(path)[0]
    nd=fitz.open(); pg=nd.new_page(width=src.mediabox.width,height=src.mediabox.height); sh=pg.new_shape()
    for d in src.get_drawings():
        if d['layer'] not in layers: continue
        for it in d['items']:
            if it[0]=='l': sh.draw_line(it[1],it[2])
            elif it[0]=='c': sh.draw_bezier(*it[1:5])
            elif it[0]=='re': sh.draw_rect(it[1])
            elif it[0]=='qu': sh.draw_quad(it[1])
        sh.finish(color=(0,0,0),width=0.7)
    sh.commit()
    z=dpi/72
    pix=pg.get_pixmap(matrix=fitz.Matrix(z,z).prerotate(angle),colorspace=fitz.csGRAY)
    return np.frombuffer(pix.samples,np.uint8).reshape(pix.height,pix.width)<128
