import json
W=lambda d:0.00617*d*d   # kg/m
B=json.load(open('olga/beams.json'))
SLAB={'2':20,'3':25,'4':25}
tot={'full':0,'below':0,'kg_main':0,'kg_stir':0}
lv={}
for k,b in B.items():
    L=k[0]; full=sum(w*h*l for w,h,l in b['seg'])/1e6
    below=sum(w*max(h-SLAB[L],0)*l for w,h,l in b['seg'])/1e6
    if k=='4.4': below=full-0.20*0.20*5.48   # upstand beam: only slab overlap excluded
    main=sum(n*l/100*W(d) for n,d,l in b['bars'])
    st=0
    for cnt,pos,w,h in b['stir']:
        Ls=(2*(w-8)+2*(h-8)+27)/100
        st+=cnt*(Ls*W(8)+(pos-1)*((w-8+20)/100)*W(8))
    lv.setdefault(L,[0,0,0,0]); a=lv[L]; a[0]+=full;a[1]+=below;a[2]+=main;a[3]+=st
    tot['full']+=full;tot['below']+=below;tot['kg_main']+=main;tot['kg_stir']+=st
for L,(f,bl,m,s) in sorted(lv.items()): print(f'level {L}: concrete full {f:.2f} m3, below-slab {bl:.2f} m3, rebar main {m:.0f} kg + stirrups {s:.0f} kg')
print({k:round(v,2) for k,v in tot.items()}, 'rebar t', round((tot['kg_main']+tot['kg_stir'])/1000,2), 'kg/m3(full)',round((tot['kg_main']+tot['kg_stir'])/tot['full']))
