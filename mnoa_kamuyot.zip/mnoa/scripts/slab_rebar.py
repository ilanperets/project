import numpy as np,cv2,json
W=lambda d:0.00617*d*d
def kg(bars): return sum(n*L/100*W(d) for n,d,L in bars)
s365_bot=[(50,12,550),(67,12,550),(7,12,515),(50,12,915),(22,12,835),(50,12,915),(4,12,760),(5,12,330),(27,12,655),(15,10,420),(11,12,765),(13,12,355),(33,12,535),(9,12,730)]
s365_top=[(3,12,430),(4,12,430),(47,12,300),(74,12,300),(11,10,250)]
g_bot=[(8,12,230),(7,12,505),(50,12,565),(67,12,565),(70,12,455),(19,12,540),(6,12,375),(64,12,485),(27,12,655),(9,12,330),(8,18,320),(15,10,445),(23,12,330),(30,12,765),(19,12,500),(50,12,515),(48,12,375),(19,8,595)]
g_top=[(30,12,300),(30,12,300),(23,10,430),(28,12,265),(11,12,430),(8,12,470),(43,12,470),(43,12,310)]
per={}
for sh in ['ק-2','ק-3']:
    m=np.load(f'olga/mask_{sh}.npy').astype(np.uint8)
    c,_=cv2.findContours(m,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
    c=max(c,key=cv2.contourArea); per[sh]=cv2.arcLength(cv2.approxPolyDP(c,3,True),True)/0.5/100
print('perimeters m',{k:round(v,1) for k,v in per.items()})
edge12=7.1
p3=per['ק-3']; p2=per['ק-2']
s365_edge=[(round((p3-edge12)/0.15),12,200),(round(edge12/0.15),12,260)]
g_edge=[(round(p2/0.15),8,195),(round(3.0/0.15),10,225)]
r={'+3.65 bottom':kg(s365_bot),'+3.65 top':kg(s365_top),'+3.65 edges':kg(s365_edge),
   '-0.15 bottom':kg(g_bot),'-0.15 top':kg(g_top),'-0.15 edges':kg(g_edge)}
for k,v in r.items(): print(f'{k:16} {v:7.0f} kg')
s365=r['+3.65 bottom']+r['+3.65 top']+r['+3.65 edges']; g=r['-0.15 bottom']+r['-0.15 top']+r['-0.15 edges']
A365=165.1-24.8  # +3.65 net excluding safe-room zone drawn on ק-0
print('slab +3.65 total',round(s365),'kg  per m2',round(s365/A365,1),' | ground total',round(g),'kg')
json.dump(dict(s365=s365,g=g,kgm2=s365/A365),open('olga/slab_rebar.json','w'))
