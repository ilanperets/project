import fitz, sys, collections
for p in sys.argv[1:]:
    d=fitz.open(p); pg=d[0]
    ocgs=d.get_ocgs()
    dr=pg.get_drawings()
    c=collections.Counter(x.get('layer') for x in dr)
    print(p.split('/')[-1], f"{pg.rect.width:.0f}x{pg.rect.height:.0f}", "ocg",len(ocgs),"draw",len(dr), "txt",len(pg.get_text('words')))
    print("   ", c.most_common(14))
