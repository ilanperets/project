import pickle, collections, numpy as np, json
O='/tmp/claude-0/-home-claude/90f9075a-8e8a-5948-8a8e-80f1167be059/scratchpad/hofim/'
W=lambda d:0.00617*d*d
R=pickle.load(open(O+'fb_160.pkl','rb'))
LEN={'060':130,'160':199,'260':88,'360':84,'460':60}
out={}
for sh,r in R.items():
    # dedupe across passes
    cc=collections.Counter(); spc=collections.Counter(); fc=collections.Counter()
    for rot,(fu,cn,sp) in r['passes'].items():
        for k,v in collections.Counter((n,d,L) for n,d,L,_ in cn).items(): cc[k]=max(cc[k],v)
        for k,v in collections.Counter((d,s,L) for d,s,L,_ in sp).items(): spc[k]=max(spc[k],v)
        for k,v in collections.Counter((n,d,s,L) for n,d,s,L,_ in fu).items(): fc[k]=max(fc[k],v)
    kg_cnt=sum(v*n*L/100*W(d) for (n,d,L),v in cc.items())+sum(v*n*L/100*W(d) for (n,d,s,L),v in fc.items())
    kface=[ (100/s)*(L/100)*W(d) for (d,s,L),v in spc.items() if s in (10,12,15,20,25,30) for _ in range(v)]
    kf=float(np.median(kface)) if kface else 0
    vert=LEN[sh]*2*kf
    nlab=sum(cc.values())+sum(spc.values())+sum(fc.values())
    out[sh]=dict(kg_cnt=kg_cnt,kface=kf,vert=vert,labels=nlab,marks=r.get('marks'),common=collections.Counter((d,s) for (d,s,L),v in spc.items()).most_common(3))
    print(sh,f"count-labels {kg_cnt:,.0f}kg  kg/m/face {kf:.1f}  vertical-mesh {vert:,.0f}kg  read {nlab}/{r.get('marks')}", out[sh]['common'])
print('total cnt',round(sum(o['kg_cnt'] for o in out.values())),'vert',round(sum(o['vert'] for o in out.values())))
json.dump(out,open(O+'wall_rebar.json','w'))
