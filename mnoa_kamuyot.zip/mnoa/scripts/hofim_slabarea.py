import sys, json, numpy as np, collections
sys.path.insert(0,'/tmp/claude-0/-home-claude/90f9075a-8e8a-5948-8a8e-80f1167be059/scratchpad/scripts')
import pymupdf as fitz
from PIL import Image
from scipy import ndimage as ndi
import hofim_fp as FP
O=FP.O; CM=2.0; z=75*0.03528/CM
def run(sh):
    F,B=FP.fp(sh)
    marks=[m for m in json.load(open(O+f'marks_{sh}.json')) if m.get('D')]
    Bl=ndi.binary_dilation(B,iterations=1)
    M=F&~Bl
    comp,n=ndi.label(M)
    seeds=np.zeros(F.shape,np.int32); info={}
    for i,m in enumerate(marks,1):
        x,y=int(m['m'][0]*z),int(m['m'][1]*z)
        # marker symbol may sit on a line; search nearby free pixel
        found=None
        for r in range(0,12):
            ys,xs=slice(max(0,y-r),y+r+1),slice(max(0,x-r),x+r+1)
            cc=comp[ys,xs]; nz=np.argwhere(cc>0)
            if len(nz): yy,xx=nz[0]; found=(ys.start+yy,xs.start+xx); break
        if found: seeds[found]=i; info[i]=m
    L=np.zeros(F.shape,np.int32)
    for c in range(1,n+1):
        sl=ndi.find_objects((comp==c).astype(int))[0]
        cm=comp[sl]==c; sd=seeds[sl]*cm
        if sd.max()==0: L[sl][cm]=-1; continue
        d,idx=ndi.distance_transform_edt(sd==0,return_indices=True)
        lab=sd[idx[0],idx[1]]; L[sl][cm]=lab[cm]
    # fill boundary pixels inside F with nearest label
    known=L!=0
    d,idx=ndi.distance_transform_edt(~known,return_indices=True)
    L2=L[idx[0],idx[1]]; L2[~F]=0
    area=collections.defaultdict(float)
    for k,v in zip(*np.unique(L2,return_counts=True)):
        if k==0: continue
        a=v*CM*CM/1e4
        key='none' if k==-1 else (f"{info[k]['D']}+{info[k]['top']}" if info[k]['top'] else f"{info[k]['D']}")
        area[key]+=a
    np.save(O+f'slabL_{sh}.npy',L2); json.dump({str(k):v for k,v in info.items()},open(O+f'slabinfo_{sh}.json','w'))
    return dict(area)
if __name__=="__main__":
    allr={}
    for sh in sys.argv[1:]:
        r=run(sh); allr[sh]=r
        print(sh,{k:round(v,1) for k,v in sorted(r.items())},"total",round(sum(r.values()),1))
    json.dump(allr,open(O+'slab_areas.json','w'))
