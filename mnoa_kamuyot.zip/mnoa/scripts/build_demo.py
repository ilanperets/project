import json,base64,html
S='/tmp/claude-0/-home-claude/90f9075a-8e8a-5948-8a8e-80f1167be059/scratchpad/olga'
b64=lambda p:'data:image/jpeg;base64,'+base64.b64encode(open(p,'rb').read()).decode()
beams=json.load(open(f'{S}/beams_demo.json'))
E=lambda s:html.escape(str(s))
def fmt(v,d=1):
    if v is None: return '—'
    s=f'{v:,.{d}f}'
    return s[:-2] if d and s.endswith('.0') else s
rows=[ # name, unit, engine, b2020, b2021, note
 ('יסודות','מ"ק',27.9,22,23,'כולל יסוד משותף אלכסוני 6.4 מ"ק בין עמודים 2–3 שלא ברור אם הוא חדש'),
 ('רצפה 20 ס"מ','מ"ר',158,157,150,''),
 ('רצפת ממ"ד 25 ס"מ','מ"ר',24.8,25,27,'צורת L: ממ"ד וחדר צמוד'),
 ('קירות בטון','מ"ק',70.3,70,86,'2021: ‏82 קירות ועוד 4 קירות מסד'),
 ('קורות','מ"ק',22.7,37,35,'21 קורות שנקראו מגיליונות הקורות, בעומק מלא'),
 ('עמודים','מ"ק',None,6,8,'רוב העמודים מוטמעים בקירות ועוד לא מופרדים'),
 ('תקרות 25 ס"מ','מ"ר',323,275,305,'כ-5 מ"ר מזה קורות בולטות שנספרו כתקרה'),
 ('תקרת ממ"ד 40 ס"מ','מ"ר',24.8,25,27,''),
 ('תקרת פיר מעלית 20 ס"מ','מ"ר',4.7,5,5,''),
]
def status(e,a,b):
    if e is None: return ('na','לא נמדד')
    d=min(abs(e-a)/a,abs(e-b)/b)
    return ('ok','תואם') if d<=0.05 else (('near','קרוב') if d<=0.15 else ('gap','פער'))
def pct(e,x):
    if e is None: return '<span class="muted">—</span>'
    p=(e-x)/x*100; cls='pos' if p>0.5 else ('neg' if p<-0.5 else 'zero')
    return f'<bdi dir="ltr" class="d {cls}">{p:+.0f}%</bdi>'
trs=[]
for n,u,e,a,b,note in rows:
    sc,st=status(e,a,b)
    trs.append(f'''<tr><th scope="row"><span class="item">{E(n)}</span>{f'<span class="note">{E(note)}</span>' if note else ''}</th>
<td class="unit">{E(u)}</td><td class="num eng" data-l="המנוע · {E(u)}">{fmt(e)}</td><td class="num" data-l="כתב 2020">{fmt(a)}<br>{pct(e,a)}</td><td class="num" data-l="אומדן 2021">{fmt(b)}<br>{pct(e,b)}</td><td><span class="pill {sc}">{st}</span></td></tr>''')
table02='\n'.join(trs)
# rebar stacked bar (axis 0..32 t)
segs=[('measured','נקרא מהתוכנית',[('קורות',2.81),('רצפה ‎−0.15',3.37),('תקרה ‎+3.65',3.22)]),
      ('derived','מחושב ממפרט השרטוט',[('ממ"ד',4.27),('עמודים וקצוות קירות',1.00)]),
      ('estimated','הערכה',[('גג ‎+7.25',3.62)])]
AX=32.0; bar=[]; legend=[]
for cls,label,items in segs:
    for nm,t in items:
        bar.append(f'<div class="seg {cls}" style="width:{t/AX*100:.3f}%" title="{E(nm)}: {t:.2f} טון"><span>{E(nm)}</span></div>')
    legend.append(f'<li><i class="sw {cls}"></i>{E(label)} · {sum(t for _,t in items):.1f} ט׳</li>')
legend.append('<li><i class="sw todo"></i>עוד לא נקרא: יסודות, מדרגות, רשת עליונה "לפי הנדרש"</li>')
marks=''.join(f'<div class="mark{" alt" if v==30 else ""}" style="right:{v/AX*100:.3f}%"><span>{lbl}<br>{v} ט׳</span></div>' for v,lbl in [(28,'כתב 2020'),(30,'אומדן 2021')])
ticks=''.join(f'<div class="tick" style="right:{v/AX*100:.3f}%"><span>{v}</span></div>' for v in range(0,31,5))
# beams list
lv_order=['רצפה ‎−0.15','תקרה ‎+3.65','גג ‎+7.25']
beam_html=[]
for lv in lv_order:
    bs=[b for b in beams if b['level']==lv]
    items=[]
    for b in bs:
        bars=''.join(f'<li>{E(x)}</li>' for x in b['bars'])
        items.append(f'''<details class="beam"><summary><span class="bid">ק {E(b['id'])}</span><span class="bsec">{E(b['sec'])}</span><span class="bk">{b['kg']:,} ק"ג</span><span class="bl">{b['L']:.2f} מ׳</span><span class="bc">{b['conc']:.2f} מ"ק</span></summary>
<div class="bars"><ul>{bars}</ul><p class="stir">חישוקים Φ8: {b['stir']} יח׳</p></div></details>''')
    beam_html.append(f'<div class="lvl"><h4>{E(lv)} <span>{len(bs)} קורות · {sum(b["kg"] for b in bs):,} ק"ג</span></h4>{"".join(items)}</div>')
beams_block='\n'.join(beam_html)
tpl=open('/tmp/claude-0/-home-claude/90f9075a-8e8a-5948-8a8e-80f1167be059/scratchpad/scripts/demo_tpl.html',encoding='utf-8').read()
out=(tpl.replace('{{TABLE02}}',table02).replace('{{BAR}}',''.join(bar)).replace('{{MARKS}}',marks).replace('{{TICKS}}',ticks)
     .replace('{{LEGEND}}',''.join(legend)).replace('{{BEAMS}}',beams_block)
     .replace('{{IMG_STRUCT}}',b64(f'{S}/img_struct.jpg')).replace('{{IMG_ARCH}}',b64(f'{S}/img_arch.jpg')).replace('{{IMG_BEAM}}',b64(f'{S}/img_beam.jpg')))
H='/tmp/claude-0/-home-claude/90f9075a-8e8a-5948-8a8e-80f1167be059/scratchpad/hofim/'
sec=open('/tmp/claude-0/-home-claude/90f9075a-8e8a-5948-8a8e-80f1167be059/scratchpad/scripts/hofim_section.html',encoding='utf-8').read().replace('{{PILE_ROWS}}',open(H+'pile_rows.html',encoding='utf-8').read()).replace('{{IMG_PB}}',b64(H+'ov_B110.jpg')).replace('{{IMG_PC}}',b64(H+'ov_C110.jpg')).replace('{{IMG_WB}}',b64(H+'fig_walls_220.jpg')).replace('{{IMG_SB}}',b64(H+'fig_slab_220.jpg')).replace('{{IMG_OCR}}',b64(H+'fig_ocr230.jpg'))
out=out.replace('{{HOFIM}}',sec)
open('/home/claude/out/kamuyot_demo.html','w',encoding='utf-8').write(out)
print('ok',len(out)//1024,'KB')
