import pdfplumber,sys,numpy as np,cv2
src,out=sys.argv[1:3]; s=0.55
p=pdfplumber.open(src).pages[0]
W=int(p.width*s);H=int(p.height*s); img=np.full((H,W,3),255,np.uint8)
def col(o):
    sc=str(o.get('stroking_color')); lw=round(o.get('linewidth') or 0,2)
    if o.get('fill'):
        return (150,150,150) if '0.65' in str(o.get('non_stroking_color')) else None
    if sc.startswith('(0.68'): return (60,200,240)   # gray hatch -> yellow-ish (BGR)
    if lw>=1.6: return (0,0,0)
    if lw==0.84: return (255,0,0)
    if lw==0.72: return (0,150,0)
    if sc=='0': return (200,0,200)
    if sc.startswith('(1.0'): return (0,0,255)
    return (190,190,190)
for o in p.curves+p.rects+p.lines:
    c=col(o)
    if c is None: continue
    pts=o.get('pts') or [(o['x0'],o['top']),(o['x1'],o['top']),(o['x1'],o['bottom']),(o['x0'],o['bottom']),(o['x0'],o['top'])]
    P=np.array([(int(x*s),int(y*s)) for x,y in pts],np.int32)
    if o.get('fill'): cv2.fillPoly(img,[P],c)
    else: cv2.polylines(img,[P],False,c,1)
cv2.imwrite(out,img)
