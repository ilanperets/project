import sys, json, math, numpy as np
sys.path.insert(0,'/tmp/claude-0/-home-claude/90f9075a-8e8a-5948-8a8e-80f1167be059/scratchpad/scripts')
import pymupdf as fitz
import hofim_vert2 as V
from scipy import ndimage as ndi
from PIL import Image
V.CM=CM=1.0
BD="/tmp/claude-0/-home-claude/90f9075a-8e8a-5948-8a8e-80f1167be059/scratchpad/corpus/hadera/T1222_hofim_highschool/קונסטרוקציה מבנה B_x/קונסטלציה מבנה B/מבנה B/CONST_B_%s.pdf"
OUT="/tmp/claude-0/-home-claude/90f9075a-8e8a-5948-8a8e-80f1167be059/scratchpad/hofim/"
z=75*0.03528/CM
def outlines(src,layer):
    def p(d): return d['items'] if d['layer']==layer and d['type']=='s' else None
    _,pg=V.replay(src,p,width=0.6,fill=False); return V.raster(pg,75,0)
def plan(sheet):
    S,Hl,src=V.masks(BD%sheet,75)
    H=ndi.binary_closing(Hl,structure=np.ones((13,13)))
    H=ndi.binary_fill_holes(H)&ndi.binary_dilation(Hl,iterations=7)
    cut=int(290*z); S[:,:cut]=False; H[:,:cut]=False; H&=~S
    dnr=outlines(src,'s_wall_DOWN'); upr=outlines(src,'S_WALL_UP')
    dn=ndi.binary_dilation(dnr,iterations=3); up=ndi.binary_dilation(upr,iterations=3)
    F=ndi.binary_fill_holes(dnr|upr)
    lab,n=ndi.label(H); Hx=np.zeros_like(H)
    for i,sl in enumerate(ndi.find_objects(lab),1):
        mm=lab[sl]==i; f=F[sl]&mm
        if f.sum()>0.6*mm.sum(): Hx[sl]|=f
        else: Hx[sl]|=ndi.binary_erosion(mm,iterations=4)
    return S,Hx&~S,Hl,dn,up
def comps(mask,kind,Hl=None,dn=None,up=None):
    lab,n=ndi.label(mask); dt=ndi.distance_transform_edt(mask); out=[]
    for i,sl in enumerate(ndi.find_objects(lab),1):
        mm=lab[sl]==i; a=mm.sum()*CM*CM/1e4
        if a<0.02: continue
        d=dt[sl]*mm; mx=ndi.maximum_filter(d,size=3); r=(d>=mx)&(d>1.5)
        if r.sum()==0: continue
        v=d[r]*2*CM; t=float(np.median(v)); spread=(np.percentile(v,90)-np.percentile(v,10))/max(t,1)
        info=dict(i=i,area=a,t=t,spread=spread,kind=kind,sl=(sl[0].start,sl[0].stop,sl[1].start,sl[1].stop))
        if kind=='hatch':
            b=mm^ndi.binary_erosion(mm,iterations=2)
            info['fd']=float((b&dn[sl]).sum()/max(1,b.sum())); info['fu']=float((b&up[sl]).sum()/max(1,b.sum()))
            info['dens']=float((Hl[sl]&mm).sum()/mm.sum())
        h=(sl[0].stop-sl[0].start)*CM; w=(sl[1].stop-sl[1].start)*CM
        info['L']=a*1e4/max(t,1)/100; info['bb']=(h,w)
        out.append(info)
    return out,lab
CLS=[20,25,30,35,40,50,60,95]
def classify(c):
    if c['t']<14 or c['spread']>0.9: return None
    h,w=c['bb']; asp=max(h,w)/max(1,min(h,w))
    if c['L']<1.3 and c['area']<1.0:
        roundish=abs(c['area']-math.pi*(max(h,w)/200)**2)<0.15*c['area'] and asp<1.25
        return 'col_round' if roundish else 'col_rect'
    return 'wall_%d'%min(CLS,key=lambda x:abs(x-c['t']))
if __name__=="__main__":
    res={}
    for sh in ['020','120','220','320','420','520']:
        S,H,Hl,dn,up=plan(sh)
        cs,labS=comps(S,'solid'); ch,labH=comps(H,'hatch',Hl,dn,up)
        np.save(OUT+f'S_{sh}.npy',np.packbits(S)); np.save(OUT+f'H_{sh}.npy',np.packbits(H))
        res[sh]=dict(shape=S.shape,solid=cs,hatch=ch)
        print(sh,"solid",len(cs),round(sum(c['area'] for c in cs),2),"hatch",len(ch),round(sum(c['area'] for c in ch),2))
    json.dump(res,open(OUT+'walls_raw.json','w'),default=lambda o: o if not isinstance(o,np.generic) else o.item())
