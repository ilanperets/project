import json, numpy as np, sys
import pymupdf as fitz
from PIL import Image
O='/tmp/claude-0/-home-claude/90f9075a-8e8a-5948-8a8e-80f1167be059/scratchpad/hofim/'
B="/tmp/claude-0/-home-claude/90f9075a-8e8a-5948-8a8e-80f1167be059/scratchpad/corpus/hadera/T1222_hofim_highschool/קונסטרוקציה מבנה B_x/קונסטלציה מבנה B/מבנה B/CONST_B_%s.pdf"
R=json.load(open(O+'walls_raw.json')); W=json.load(open(O+'walls_vol.json'))
sh=sys.argv[1]; crop=[float(x) for x in sys.argv[2].split(',')]
shp=tuple(R[sh]['shape'])
load=lambda n: np.unpackbits(np.load(O+f'{n}_{sh}.npy'))[:shp[0]*shp[1]].reshape(shp).astype(bool)
Sm,Hm=load('S'),load('H')
COL={'wall_20':(46,125,79),'wall_25':(140,180,40),'wall_30':(200,160,0),'wall_35':(230,120,0),'wall_40':(200,50,40),'wall_45':(140,40,130),'col_rect':(25,90,170),'col_round':(0,150,200)}
lab=np.zeros(shp,np.uint8); keys=list(COL)
for it in W['items']:
    if it['sh']!=sh: continue
    y0,y1,x0,x1=it['sl']; m=(Sm if it['kind']=='solid' else Hm)[y0:y1,x0:x1]
    k=it['k'].split('_',1)[1] if it['k'].startswith(('base_','found_')) else it['k']
    if k in COL: lab[y0:y1,x0:x1][m]=keys.index(k)+1
pg=fitz.open(B%sh)[0]; dpi=60
pix=pg.get_pixmap(dpi=dpi); bg=Image.frombytes("RGB",[pix.width,pix.height],pix.samples)
bg=Image.blend(bg,Image.new("RGB",bg.size,"white"),0.6)
L=Image.fromarray(lab).resize(bg.size,Image.NEAREST); L=np.array(L)
# thicken: max filter
from scipy import ndimage as ndi
L=ndi.maximum_filter(L,size=3)
a=np.array(bg)
for i,k in enumerate(keys,1): a[L==i]=COL[k]
im=Image.fromarray(a); w,h=im.size
im=im.crop((int(w*crop[0]),int(h*crop[1]),int(w*crop[2]),int(h*crop[3])))
im.save(O+f'fig_walls_{sh}.jpg',quality=84); print(im.size)
