import json, numpy as np, sys
import pymupdf as fitz
from PIL import Image, ImageDraw
from scipy import ndimage as ndi
O='/tmp/claude-0/-home-claude/90f9075a-8e8a-5948-8a8e-80f1167be059/scratchpad/hofim/'
BD="/tmp/claude-0/-home-claude/90f9075a-8e8a-5948-8a8e-80f1167be059/scratchpad/corpus/hadera/T1222_hofim_highschool/קונסטרוקציה מבנה B_x/קונסטלציה מבנה B/מבנה B/CONST_B_%s.pdf"
sh=sys.argv[1]; crop=[float(x) for x in sys.argv[2].split(',')]
L=np.load(O+f'slabL_{sh}.npy'); shp=L.shape
P=np.unpackbits(np.load(O+f'slabP_{sh}.npy'))[:shp[0]*shp[1]].reshape(shp).astype(bool)
marks=[m for m in json.load(open(O+f'marks_{sh}.json')) if m.get('D')]
COL={20:(30,110,200),30:(240,170,60),36:(200,90,160),40:(200,60,50),75:(90,60,40),25:(130,200,120),15:(180,180,180)}
D=np.zeros(shp,np.int16)
for i,m in enumerate(marks,1): D[L==i]=m['D']
pg=fitz.open(BD%sh)[0]; pix=pg.get_pixmap(dpi=60)
bg=Image.frombytes("RGB",[pix.width,pix.height],pix.samples)
Dr=np.array(Image.fromarray(D).resize(bg.size,Image.NEAREST)); Pr=np.array(Image.fromarray(P).resize(bg.size,Image.NEAREST))
a=np.array(bg).astype(float)
m=Dr>0
a[m]=a[m]*0.55+np.array((120,180,230))*0.45
# precast: diagonal stripes
yy,xx=np.mgrid[0:a.shape[0],0:a.shape[1]]
stripe=((xx+yy)//5)%3==0
a[Pr&stripe]=a[Pr&stripe]*0.5
im=Image.fromarray(a.astype(np.uint8)); dr=ImageDraw.Draw(im); k=60/72
for mk in marks:
    x,y=mk['m'][0]*k,mk['m'][1]*k; c=COL.get(mk['D'],(0,0,0)); r=9
    dr.ellipse([x-r,y-r,x+r,y+r],fill=c,outline=(0,0,0),width=2)
w,h=im.size
im=im.crop((int(w*crop[0]),int(h*crop[1]),int(w*crop[2]),int(h*crop[3])))
im.thumbnail((1500,1500)); im.save(O+f'fig_slab_{sh}.jpg',quality=82); print(im.size)
