import json,sys,re,math
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon
from bidi.algorithm import get_display
src=open(sys.argv[2]).read().split('# walls')[0]; exec(src)
plt.rcParams['font.family']='DejaVu Sans'
xs=[p for e in E if e['type']=='LINE' and e['layer']=='A-WALL' for p in (e['startPoint']['x'],e['endPoint']['x'])]
ys=[p for e in E if e['type']=='LINE' and e['layer']=='A-WALL' for p in (e['startPoint']['y'],e['endPoint']['y'])]
x0,x1,y0,y1=min(xs)-800,max(xs)+800,min(ys)-800,max(ys)+800
fig,ax=plt.subplots(figsize=(22,22*(y1-y0)/(x1-x0)),dpi=110)
H=lambda s: s
# floor zones
import colorsys
for i,h in enumerate([h for h in E if h['type']=='HATCH' and h['layer']=='A-FLOR-PATT']):
    ps=sorted(poly(h),key=area,reverse=True)
    ax.add_patch(Polygon(ps[0],closed=True,fc=(0.93,0.90,0.80,0.55),ec='none',zorder=0))
for e in E:
    if e['type']=='LINE' and e['layer'] in ('A-WALL','I-WALL','A-FLOR','A-DETL-THIN','A-GLAZ-CWMG','A-DOOR'):
        c={'A-WALL':'#333','I-WALL':'#555'}.get(e['layer'],'#bbb'); lw=0.6 if e['layer'] in('A-WALL','I-WALL') else 0.3
        ax.plot([e['startPoint']['x'],e['endPoint']['x']],[e['startPoint']['y'],e['endPoint']['y']],color=c,lw=lw,zorder=2)
for h in E:
    if h['type']=='HATCH' and h['layer']=='A-WALL-PATT':
        for pts in poly(h):
            A=area(pts);P=perim(pts);s=P/2;t=(s-math.sqrt(max(s*s-4*A,0)))/2
            col='#1f3b57' if t>=150 else ('#3f7cac' if t>=90 else '#9cc3df')
            ax.add_patch(Polygon(pts,closed=True,fc=col,ec='none',zorder=3))
for e in E:
    if e['type']!='INSERT': continue
    p=e['insertionPoint']
    if e['layer']=='A-DOOR': ax.plot(p['x'],p['y'],'o',ms=9,mfc='#c0392b',mec='white',zorder=6)
    elif e['layer']=='S-COLS': ax.plot(p['x'],p['y'],'s',ms=8,mfc='#111',mec='white',zorder=6)
    elif e['layer']=='A-GLAZ-CURT': ax.plot(p['x'],p['y'],'D',ms=5,mfc='#16a085',mec='none',zorder=5)
    elif e['layer']=='P-SANR-FIXT': ax.plot(p['x'],p['y'],'^',ms=7,mfc='#8e44ad',mec='white',zorder=6)
    elif e['layer']=='E-ELEC-FIXT': ax.plot(p['x'],p['y'],'*',ms=10,mfc='#e67e22',mec='white',zorder=6)
T=[(e['insertionPoint']['x'],e['insertionPoint']['y'],clean(e['text'])) for e in E if e['type']=='MTEXT' and e['layer']=='A-AREA-IDEN']
for x,y,t in T:
    if t in('.','ח'): continue
    ax.text(x,y,H(t),fontsize=8.5,zorder=8,ha='left',va='bottom',color='#222',bbox=dict(fc='white',ec='none',alpha=.7,pad=1) if re.fullmatch(r'[\d-]+',t) else None)
ax.set_xlim(x0,x1);ax.set_ylim(y0,y1);ax.set_aspect('equal');ax.axis('off')
from matplotlib.lines import Line2D
lg=[Line2D([],[],marker='s',ls='',mfc='#1f3b57',mec='none',ms=11,label=H('קיר 150 מ"מ ומעלה')),
    Line2D([],[],marker='s',ls='',mfc='#3f7cac',mec='none',ms=11,label=H('קיר 100 מ"מ')),
    Line2D([],[],marker='s',ls='',mfc='#9cc3df',mec='none',ms=11,label=H('שכבות גמר 10–50 מ"מ')),
    Line2D([],[],marker='o',ls='',mfc='#c0392b',ms=10,label=H('דלת (29)')),
    Line2D([],[],marker='s',ls='',mfc='#111',ms=9,label=H('עמוד (18)')),
    Line2D([],[],marker='D',ls='',mfc='#16a085',ms=7,label=H('פנל זכוכית (47)')),
    Line2D([],[],marker='^',ls='',mfc='#8e44ad',ms=9,label=H('כלים סניטריים (23)')),
    Line2D([],[],marker='*',ls='',mfc='#e67e22',ms=12,label=H('נקודות חשמל (13)'))]
ax.legend(handles=lg,loc='upper center',bbox_to_anchor=(0.5,-0.01),ncol=8,frameon=False,fontsize=11)
ax.set_title(H('זיהוי אוטומטי מתוך הקובץ – A03 אנדואורולוגיה, שיבא'),fontsize=16,pad=10)
plt.savefig(sys.argv[3],bbox_inches='tight',facecolor='white')
