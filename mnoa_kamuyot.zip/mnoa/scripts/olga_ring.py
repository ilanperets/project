import pdfplumber,sys,math,json
from shapely.geometry import LineString,Polygon
from shapely.ops import unary_union,polygonize
K=sys.argv[1]; CM=0.35278*50/10; BB=(590,40,1360,1060)
for sh in ['ק-3','ק-4']:
    p=pdfplumber.open(f'{K}/{sh}.pdf').pages[0]
    segs=[]
    for l in p.lines+p.curves+p.rects:
        if round(l.get('linewidth') or 0,2)!=1.42 or l.get('fill'): continue
        pts=l.get('pts') or [(l['x0'],l['top']),(l['x1'],l['top']),(l['x1'],l['bottom']),(l['x0'],l['bottom']),(l['x0'],l['top'])]
        if not all(BB[0]<=x<=BB[2] and BB[1]<=y<=BB[3] for x,y in pts): continue
        for a,b in zip(pts,pts[1:]):
            if math.dist(a,b)>0.5: segs.append(LineString([(a[0]*CM,a[1]*CM),(b[0]*CM,b[1]*CM)]))
    faces=list(polygonize(unary_union(segs)))
    # wall faces: thin (2A/P small); skip big room interiors
    walls=[];rooms=[]
    for f in faces:
        A=f.area/1e4; P=f.length/100; t=2*A/P
        r=f.minimum_rotated_rectangle.exterior.coords; d=sorted([math.dist(r[0],r[1]),math.dist(r[1],r[2])])
        (walls if t<0.5 else rooms).append((round(A,3),round(t*100),[round(d[0]),round(d[1])]))
    print(sh,'segs',len(segs),'faces',len(faces))
    print('  wall/col faces:',sorted(walls,key=lambda x:-x[0]))
    print('  sum wall-like m2',round(sum(w[0] for w in walls),3))
    print('  big faces:',sorted(rooms,key=lambda x:-x[0])[:6])
