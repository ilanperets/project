import pytesseract, sys, json
from PIL import Image; Image.MAX_IMAGE_PIXELS=None
im=Image.open(sys.argv[1]); W,H=im.size
out=[]
for rot in (0,90,-90):
    r=im if rot==0 else im.rotate(rot,expand=True)
    d=pytesseract.image_to_data(r, config='--psm 11', output_type=pytesseract.Output.DICT)
    for i in range(len(d['text'])):
        t=d['text'][i].strip()
        if not t: continue
        u=d['left'][i]+d['width'][i]/2; v=d['top'][i]+d['height'][i]/2
        if rot==0: x,y=u,v
        elif rot==90: x,y=W-1-v,u
        else: x,y=v,H-1-u
        # store as left/top-ish with zero size, center coords
        out.append((t,x,y,0,0,float(d['conf'][i]),rot))
json.dump(out,open(sys.argv[2],'w')); print(len(out))
