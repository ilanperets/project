import json,sys,collections,re,math
exec(open(sys.argv[2]).read().split('# walls')[0])
res=[]
for h in E:
    if h['type']=='HATCH' and h['layer']=='A-FLOR-PATT':
        ps=sorted(poly(h),key=area,reverse=True)
        outer=ps[0]; holes=[p for p in ps[1:]]
        net=area(outer)-sum(area(p) for p in holes)
        res.append((h['patternName'],len(ps),round(area(outer)/1e6,2),round(net/1e6,2),[round(c) for c in outer[0]]))
for r in sorted(res): print(r)
print('total net',round(sum(r[3] for r in res),2))
